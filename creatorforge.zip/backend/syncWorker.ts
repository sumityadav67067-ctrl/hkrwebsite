import type { Response } from 'express';
import { getChannelStats, getSiteConfig } from './db.ts';
import { generateAndApplyChannelBranding } from './brandingService.ts';
import { syncYouTubeChannel } from './youtubeService.ts';

const sseClients = new Set<Response>();
let syncInFlight = false;
let timersStarted = false;

export function registerSseClient(res: Response): void {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  sseClients.add(res);

  const heartbeat = setInterval(() => {
    try {
      res.write(': keepalive\n\n');
    } catch {
      clearInterval(heartbeat);
      sseClients.delete(res);
    }
  }, 25000);

  res.on('close', () => {
    clearInterval(heartbeat);
    sseClients.delete(res);
  });
}

export function broadcastSseEvent(event: string, payload: Record<string, unknown>): void {
  const data = `event: ${event}\ndata: ${JSON.stringify(payload)}\n\n`;
  for (const client of sseClients) {
    try {
      client.write(data);
    } catch {
      sseClients.delete(client);
    }
  }
}

export async function runSyncTask(
  type: 'all' | 'subscribers' | 'videos' | 'live' = 'all',
  rebrand = false
): Promise<{ success: boolean; mode: 'youtube-api' | 'public-feed'; error?: string }> {
  if (syncInFlight) {
    return {
      success: true,
      mode: process.env.YOUTUBE_API_KEY?.trim() ? 'youtube-api' : 'public-feed',
    };
  }
  syncInFlight = true;
  try {
    const result = await syncYouTubeChannel(type);
    if (rebrand) {
      await generateAndApplyChannelBranding();
    }
    broadcastSseEvent('channel-updated', {
      type,
      updatedAt: new Date().toISOString(),
      stats: getChannelStats(),
      site: getSiteConfig(),
    });
    return result;
  } finally {
    syncInFlight = false;
  }
}

export function startBackgroundWorkers(): void {
  if (timersStarted) return;
  timersStarted = true;

  const subInterval = Math.max(60000, Number(process.env.SUBSCRIBER_REFRESH_INTERVAL) || 300000);
  const videoInterval = Math.max(120000, Number(process.env.VIDEO_REFRESH_INTERVAL) || 600000);
  const liveInterval = Math.max(45000, Number(process.env.LIVE_REFRESH_INTERVAL) || 120000);

  // Initial sync shortly after boot without blocking port startup
  setTimeout(() => {
    const stats = getChannelStats();
    const shouldRebrand = !stats.last_video_sync;
    runSyncTask('all', shouldRebrand).catch(() => {});
  }, 400);

  setInterval(() => {
    runSyncTask('subscribers').catch(() => {});
  }, subInterval);

  setInterval(() => {
    runSyncTask('videos').catch(() => {});
  }, videoInterval);

  setInterval(() => {
    runSyncTask('live').catch(() => {});
  }, liveInterval);
}
