import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';

const DATA_DIR = path.resolve(process.cwd(), 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const DB_PATH = path.join(DATA_DIR, 'creator.db');
export const db = new Database(DB_PATH);

db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

export function initDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS site_config (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      channel_name TEXT NOT NULL,
      youtube_channel_url TEXT NOT NULL,
      discord_invite_url TEXT NOT NULL,
      desired_port INTEGER NOT NULL DEFAULT 25595,
      channel_id TEXT,
      channel_handle TEXT,
      avatar_url TEXT,
      banner_url TEXT,
      channel_description TEXT,
      niche TEXT NOT NULL DEFAULT 'Content Creator',
      categories_json TEXT NOT NULL DEFAULT '["Latest Uploads","Highlights","Community"]',
      hero_headline TEXT NOT NULL,
      hero_subheadline TEXT NOT NULL,
      about_text TEXT NOT NULL,
      community_pitch TEXT NOT NULL,
      theme_mode TEXT NOT NULL DEFAULT 'dark',
      primary_color TEXT NOT NULL DEFAULT '#f59e0b',
      secondary_color TEXT NOT NULL DEFAULT '#1e293b',
      accent_color TEXT NOT NULL DEFAULT '#fbbf24',
      font_display TEXT NOT NULL DEFAULT 'Outfit',
      font_body TEXT NOT NULL DEFAULT 'Plus Jakarta Sans',
      social_links_json TEXT NOT NULL DEFAULT '{}',
      featured_video_id TEXT,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS channel_stats (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      subscriber_count INTEGER,
      subscriber_display TEXT,
      hidden_subscriber_count INTEGER NOT NULL DEFAULT 0,
      subscriber_source TEXT NOT NULL DEFAULT 'unavailable',
      subscriber_unavailable_reason TEXT,
      view_count INTEGER,
      video_count INTEGER,
      is_live INTEGER NOT NULL DEFAULT 0,
      live_video_id TEXT,
      live_title TEXT,
      live_thumbnail TEXT,
      live_started_at TEXT,
      live_viewers INTEGER,
      upcoming_live_json TEXT NOT NULL DEFAULT '[]',
      last_subscriber_sync TEXT,
      last_video_sync TEXT,
      last_live_sync TEXT,
      last_error TEXT
    );

    CREATE TABLE IF NOT EXISTS videos (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      description TEXT NOT NULL DEFAULT '',
      thumbnail_url TEXT NOT NULL,
      published_at TEXT NOT NULL,
      duration_seconds INTEGER,
      duration_formatted TEXT,
      view_count INTEGER,
      like_count INTEGER,
      category TEXT NOT NULL DEFAULT 'Upload',
      is_short INTEGER NOT NULL DEFAULT 0,
      short_checked INTEGER NOT NULL DEFAULT 0,
      is_livestream INTEGER NOT NULL DEFAULT 0,
      live_status TEXT NOT NULL DEFAULT 'none',
      is_featured INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS contact_submissions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      inquiry_type TEXT NOT NULL,
      company TEXT DEFAULT '',
      message TEXT NOT NULL,
      is_read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS admin_users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS admin_sessions (
      token TEXT PRIMARY KEY,
      csrf_token TEXT NOT NULL,
      user_id INTEGER NOT NULL,
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES admin_users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS sync_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sync_type TEXT NOT NULL,
      status TEXT NOT NULL,
      message TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
  `);

  const existingSite = db.prepare('SELECT id FROM site_config WHERE id = 1').get();
  if (!existingSite) {
    const channelName = (process.env.CHANNEL_NAME || 'HkR PlayZ').trim();
    const youtubeUrl = (process.env.YOUTUBE_CHANNEL_URL || 'https://www.youtube.com/@hkrplayz').trim();
    const discordUrl = (process.env.DISCORD_INVITE_URL || 'https://discord.gg/WP5g3uehWd').trim();
    const desiredPort = Number(process.env.DESIRED_PORT || process.env.PORT || 25595) || 25595;
    const now = new Date().toISOString();

    db.prepare(`
      INSERT INTO site_config (
        id, channel_name, youtube_channel_url, discord_invite_url, desired_port,
        channel_id, channel_handle, avatar_url, banner_url, channel_description,
        niche, categories_json, hero_headline, hero_subheadline, about_text, community_pitch,
        theme_mode, primary_color, secondary_color, accent_color, font_display, font_body,
        social_links_json, featured_video_id, updated_at
      ) VALUES (
        1, ?, ?, ?, ?,
        NULL, NULL, NULL, NULL, '',
        'Content Creator', '["Latest Uploads","Shorts","Community"]',
        ?, ?, ?, ?,
        'dark', '#f59e0b', '#1e293b', '#fbbf24', 'Outfit', 'Plus Jakarta Sans',
        '{}', NULL, ?
      )
    `).run(
      channelName,
      youtubeUrl,
      discordUrl,
      desiredPort,
      `${channelName} — Official Creator Hub`,
      `Latest YouTube videos, verified Shorts, live stream status, and Discord community for ${channelName}.`,
      `Welcome to the official digital home of ${channelName}. Watch the newest uploads, explore Shorts, check live stream status, and connect on Discord.`,
      `Join the official ${channelName} Discord server to chat with the community, get upload alerts, and participate in events.`,
      now
    );
  }

  const existingStats = db.prepare('SELECT id FROM channel_stats WHERE id = 1').get();
  if (!existingStats) {
    db.prepare(`
      INSERT INTO channel_stats (
        id, subscriber_count, subscriber_display, hidden_subscriber_count,
        subscriber_source, subscriber_unavailable_reason
      ) VALUES (1, NULL, NULL, 0, 'pending', 'Initial channel synchronization in progress.')
    `).run();
  }
}

export interface SiteConfigRow {
  id: number;
  channel_name: string;
  youtube_channel_url: string;
  discord_invite_url: string;
  desired_port: number;
  channel_id: string | null;
  channel_handle: string | null;
  avatar_url: string | null;
  banner_url: string | null;
  channel_description: string;
  niche: string;
  categories_json: string;
  hero_headline: string;
  hero_subheadline: string;
  about_text: string;
  community_pitch: string;
  theme_mode: 'dark' | 'light';
  primary_color: string;
  secondary_color: string;
  accent_color: string;
  font_display: string;
  font_body: string;
  social_links_json: string;
  featured_video_id: string | null;
  updated_at: string;
}

export interface ChannelStatsRow {
  id: number;
  subscriber_count: number | null;
  subscriber_display: string | null;
  hidden_subscriber_count: number;
  subscriber_source: string;
  subscriber_unavailable_reason: string | null;
  view_count: number | null;
  video_count: number | null;
  is_live: number;
  live_video_id: string | null;
  live_title: string | null;
  live_thumbnail: string | null;
  live_started_at: string | null;
  live_viewers: number | null;
  upcoming_live_json: string;
  last_subscriber_sync: string | null;
  last_video_sync: string | null;
  last_live_sync: string | null;
  last_error: string | null;
}

export interface VideoRow {
  id: string;
  title: string;
  description: string;
  thumbnail_url: string;
  published_at: string;
  duration_seconds: number | null;
  duration_formatted: string | null;
  view_count: number | null;
  like_count: number | null;
  category: string;
  is_short: number;
  short_checked: number;
  is_livestream: number;
  live_status: string;
  is_featured: number;
  updated_at: string;
}

export function getSiteConfig(): SiteConfigRow {
  return db.prepare('SELECT * FROM site_config WHERE id = 1').get() as SiteConfigRow;
}

export function getChannelStats(): ChannelStatsRow {
  return db.prepare('SELECT * FROM channel_stats WHERE id = 1').get() as ChannelStatsRow;
}

export function addSyncLog(syncType: string, status: 'ok' | 'error' | 'warn', message: string) {
  db.prepare('INSERT INTO sync_logs (sync_type, status, message, created_at) VALUES (?, ?, ?, ?)').run(
    syncType,
    status,
    message.slice(0, 1000),
    new Date().toISOString()
  );
  // Keep log table tidy (max 200 entries)
  db.prepare(`
    DELETE FROM sync_logs
    WHERE id NOT IN (SELECT id FROM sync_logs ORDER BY id DESC LIMIT 200)
  `).run();
}
