import { GoogleGenAI, Type } from '@google/genai';
import { db, getSiteConfig, type VideoRow } from './db.ts';

export interface GeneratedBranding {
  niche: string;
  categories: string[];
  themeMode: 'dark' | 'light';
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  fontDisplay: 'Outfit' | 'Barlow Condensed' | 'Bricolage Grotesque' | 'Archivo' | 'Playfair Display';
  fontBody: 'Plus Jakarta Sans' | 'DM Sans' | 'Manrope' | 'Public Sans' | 'Source Serif 4';
  heroHeadline: string;
  heroSubheadline: string;
  aboutText: string;
  communityPitch: string;
  source: 'gemini-ai' | 'deterministic-niche';
}

interface NichePreset {
  niche: string;
  keywords: string[];
  categories: string[];
  themeMode: 'dark' | 'light';
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  fontDisplay: GeneratedBranding['fontDisplay'];
  fontBody: GeneratedBranding['fontBody'];
}

const NICHE_PRESETS: NichePreset[] = [
  {
    niche: 'Minecraft & Sandbox Gaming',
    keywords: ['minecraft', 'smp', 'bedwars', 'skyblock', 'redstone', 'modpack', 'survival', 'creeper'],
    categories: ['Minecraft Survival', 'SMP Highlights', 'Shorts', 'Community Events'],
    themeMode: 'dark',
    primaryColor: '#10b981',
    secondaryColor: '#1e293b',
    accentColor: '#34d399',
    fontDisplay: 'Bricolage Grotesque',
    fontBody: 'Plus Jakarta Sans',
  },
  {
    niche: 'Free Fire & Mobile Esports',
    keywords: ['free fire', 'ff', 'booyah', 'headshot', 'bgmi', 'pubg', 'clutch', 'ranked', 'garena'],
    categories: ['Ranked Highlights', 'Gameplay Clips', 'Shorts', 'Tournaments'],
    themeMode: 'dark',
    primaryColor: '#f59e0b',
    secondaryColor: '#1e293b',
    accentColor: '#fbbf24',
    fontDisplay: 'Barlow Condensed',
    fontBody: 'DM Sans',
  },
  {
    niche: 'Gaming & Livestreams',
    keywords: ['playz', 'gaming', 'gameplay', 'walkthrough', 'valorant', 'fortnite', 'gta', 'stream', 'fps', 'boss'],
    categories: ['Gameplay', 'Live Streams', 'Shorts', 'Highlights'],
    themeMode: 'dark',
    primaryColor: '#f59e0b',
    secondaryColor: '#1e293b',
    accentColor: '#fbbf24',
    fontDisplay: 'Outfit',
    fontBody: 'Plus Jakarta Sans',
  },
  {
    niche: 'Technology & Engineering',
    keywords: ['tech', 'review', 'laptop', 'gpu', 'coding', 'developer', 'software', 'benchmark', 'iphone', 'hardware'],
    categories: ['Deep Dives', 'Reviews', 'Benchmarks', 'Shorts'],
    themeMode: 'dark',
    primaryColor: '#0284c7',
    secondaryColor: '#0f172a',
    accentColor: '#38bdf8',
    fontDisplay: 'Archivo',
    fontBody: 'Public Sans',
  },
  {
    niche: 'Education & Tutorials',
    keywords: ['learn', 'tutorial', 'course', 'math', 'science', 'study', 'explained', 'guide', 'lesson', 'academy'],
    categories: ['Guides', 'Explainers', 'Series', 'Shorts'],
    themeMode: 'light',
    primaryColor: '#1d4ed8',
    secondaryColor: '#f1f5f9',
    accentColor: '#2563eb',
    fontDisplay: 'Outfit',
    fontBody: 'Public Sans',
  },
  {
    niche: 'Music & Audio Production',
    keywords: ['music', 'beat', 'song', 'cover', 'remix', 'studio', 'guitar', 'piano', 'audio', 'synth', 'album'],
    categories: ['Releases', 'Live Sessions', 'Studio Breakdowns', 'Shorts'],
    themeMode: 'dark',
    primaryColor: '#e11d48',
    secondaryColor: '#18181b',
    accentColor: '#fb7185',
    fontDisplay: 'Playfair Display',
    fontBody: 'Manrope',
  },
  {
    niche: 'Vlogging & Lifestyle',
    keywords: ['vlog', 'travel', 'daily', 'day in the life', 'story', 'adventure', 'lifestyle', 'challenge'],
    categories: ['Vlogs', 'Stories', 'Behind the Scenes', 'Shorts'],
    themeMode: 'light',
    primaryColor: '#d97706',
    secondaryColor: '#f8fafc',
    accentColor: '#f59e0b',
    fontDisplay: 'Playfair Display',
    fontBody: 'Source Serif 4',
  },
];

function deterministicAnalyze(
  channelName: string,
  description: string,
  videoTitles: string[]
): GeneratedBranding {
  const corpus = `${channelName} ${description} ${videoTitles.join(' ')}`.toLowerCase();
  let bestPreset: NichePreset | null = null;
  let bestScore = 0;

  for (const preset of NICHE_PRESETS) {
    let score = 0;
    for (const kw of preset.keywords) {
      if (corpus.includes(kw)) score++;
    }
    if (score > bestScore) {
      bestScore = score;
      bestPreset = preset;
    }
  }

  const chosen = bestPreset || {
    niche: 'Digital Entertainment & Video',
    categories: ['Latest Uploads', 'Featured Videos', 'Shorts', 'Community'],
    themeMode: 'dark' as const,
    primaryColor: '#f59e0b',
    secondaryColor: '#1e293b',
    accentColor: '#fbbf24',
    fontDisplay: 'Outfit' as const,
    fontBody: 'Plus Jakarta Sans' as const,
  };

  return {
    niche: chosen.niche,
    categories: chosen.categories,
    themeMode: chosen.themeMode,
    primaryColor: chosen.primaryColor,
    secondaryColor: chosen.secondaryColor,
    accentColor: chosen.accentColor,
    fontDisplay: chosen.fontDisplay,
    fontBody: chosen.fontBody,
    heroHeadline: `${channelName} — ${chosen.niche}`,
    heroSubheadline: description
      ? description.slice(0, 180).trim()
      : `Watch the latest videos, verified Shorts, and live broadcasts from ${channelName}.`,
    aboutText: description
      ? description
      : `Welcome to the official creator hub for ${channelName}. Explore recent uploads, discover verified Shorts, check live stream status, and join our Discord community.`,
    communityPitch: `Connect directly with ${channelName} and fellow subscribers on Discord for live stream notifications, community events, and updates.`,
    source: 'deterministic-niche',
  };
}

export async function generateAndApplyChannelBranding(): Promise<GeneratedBranding> {
  const site = getSiteConfig();
  const recentVideos = db
    .prepare('SELECT title FROM videos ORDER BY published_at DESC LIMIT 12')
    .all() as Pick<VideoRow, 'title'>[];
  const titles = recentVideos.map((v) => v.title);

  const geminiKey = process.env.GEMINI_API_KEY?.trim();
  let result: GeneratedBranding | null = null;

  if (geminiKey) {
    try {
      const ai = new GoogleGenAI({
        apiKey: geminiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      });

      const prompt = [
        `Analyze this YouTube content creator and design a bespoke, cohesive website brand identity.`,
        `Channel Name: ${site.channel_name}`,
        `Channel Handle: ${site.channel_handle || 'unknown'}`,
        `Channel Description: ${site.channel_description || 'Not available'}`,
        `Recent Video Titles: ${titles.length > 0 ? titles.join(' | ') : 'Not yet retrieved'}`,
        `Rules:`,
        `- Never assume gaming unless evidence exists in the channel name, description, or video titles.`,
        `- Never fabricate channel milestones, sponsors, or subscriber figures.`,
        `- Keep copy crisp, natural, and free of buzzwords.`,
        `- Choose high-contrast accessible hex colors (primaryColor and accentColor must work well on the chosen themeMode).`,
      ].join('\n');

      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: prompt,
        config: {
          systemInstruction:
            'You are an editorial brand director and YouTube channel analyst. Return strictly valid JSON matching the schema.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              niche: { type: Type.STRING, description: 'Detected primary content niche (e.g. Minecraft Gaming, Technology, Music, Education, Vlogging).' },
              categories: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: '3 to 4 concise content categories tailored to this channel.',
              },
              themeMode: { type: Type.STRING, description: 'Either dark or light.' },
              primaryColor: { type: Type.STRING, description: 'Accessible brand hex color, e.g. #f59e0b or #0284c7.' },
              secondaryColor: { type: Type.STRING, description: 'Complementary surface hex color, e.g. #1e293b or #f1f5f9.' },
              accentColor: { type: Type.STRING, description: 'High-contrast accent hex color.' },
              fontDisplay: {
                type: Type.STRING,
                description: 'Must be one of: Outfit, Barlow Condensed, Bricolage Grotesque, Archivo, Playfair Display',
              },
              fontBody: {
                type: Type.STRING,
                description: 'Must be one of: Plus Jakarta Sans, DM Sans, Manrope, Public Sans, Source Serif 4',
              },
              heroHeadline: { type: Type.STRING, description: 'Short 4-8 word hero headline for the creator hub.' },
              heroSubheadline: { type: Type.STRING, description: '1-2 concise sentences introducing the channel.' },
              aboutText: { type: Type.STRING, description: 'Clean 2-3 sentence creator bio grounded in verified channel info.' },
              communityPitch: { type: Type.STRING, description: '1-2 sentences inviting visitors to the Discord community.' },
            },
            required: [
              'niche',
              'categories',
              'themeMode',
              'primaryColor',
              'secondaryColor',
              'accentColor',
              'fontDisplay',
              'fontBody',
              'heroHeadline',
              'heroSubheadline',
              'aboutText',
              'communityPitch',
            ],
          },
        },
      });

      const parsed = JSON.parse((response.text || '{}').trim());
      const allowedDisplay = ['Outfit', 'Barlow Condensed', 'Bricolage Grotesque', 'Archivo', 'Playfair Display'];
      const allowedBody = ['Plus Jakarta Sans', 'DM Sans', 'Manrope', 'Public Sans', 'Source Serif 4'];
      const isHex = (c: unknown) => typeof c === 'string' && /^#[0-9a-fA-F]{6}$/.test(c);

      result = {
        niche: typeof parsed.niche === 'string' && parsed.niche ? parsed.niche : 'Content Creator',
        categories:
          Array.isArray(parsed.categories) && parsed.categories.length > 0
            ? parsed.categories.slice(0, 4).map(String)
            : ['Latest Uploads', 'Shorts', 'Community'],
        themeMode: parsed.themeMode === 'light' ? 'light' : 'dark',
        primaryColor: isHex(parsed.primaryColor) ? parsed.primaryColor : '#f59e0b',
        secondaryColor: isHex(parsed.secondaryColor) ? parsed.secondaryColor : '#1e293b',
        accentColor: isHex(parsed.accentColor) ? parsed.accentColor : '#fbbf24',
        fontDisplay: allowedDisplay.includes(parsed.fontDisplay) ? parsed.fontDisplay : 'Outfit',
        fontBody: allowedBody.includes(parsed.fontBody) ? parsed.fontBody : 'Plus Jakarta Sans',
        heroHeadline: String(parsed.heroHeadline || `${site.channel_name} — Official Hub`).slice(0, 120),
        heroSubheadline: String(parsed.heroSubheadline || '').slice(0, 260),
        aboutText: String(parsed.aboutText || '').slice(0, 1000),
        communityPitch: String(parsed.communityPitch || '').slice(0, 400),
        source: 'gemini-ai',
      };
    } catch {
      result = null;
    }
  }

  if (!result) {
    result = deterministicAnalyze(site.channel_name, site.channel_description || '', titles);
  }

  db.prepare(`
    UPDATE site_config
    SET niche = ?,
        categories_json = ?,
        theme_mode = ?,
        primary_color = ?,
        secondary_color = ?,
        accent_color = ?,
        font_display = ?,
        font_body = ?,
        hero_headline = ?,
        hero_subheadline = ?,
        about_text = ?,
        community_pitch = ?,
        updated_at = ?
    WHERE id = 1
  `).run(
    result.niche,
    JSON.stringify(result.categories),
    result.themeMode,
    result.primaryColor,
    result.secondaryColor,
    result.accentColor,
    result.fontDisplay,
    result.fontBody,
    result.heroHeadline,
    result.heroSubheadline,
    result.aboutText,
    result.communityPitch,
    new Date().toISOString()
  );

  return result;
}
