import { addSyncLog, db, getChannelStats, getSiteConfig } from './db.ts';

const YOUTUBE_API_BASE = 'https://www.googleapis.com/youtube/v3';
const USER_AGENT =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

export interface ParsedChannelTarget {
  rawUrl: string;
  channelId?: string;
  handle?: string;
  username?: string;
  customPath?: string;
}

export function parseYouTubeChannelUrl(input: string): ParsedChannelTarget {
  const trimmed = input.trim();
  if (/^UC[\w-]{20,}$/.test(trimmed)) {
    return { rawUrl: `https://www.youtube.com/channel/${trimmed}`, channelId: trimmed };
  }
  if (/^@[\w.-]+$/.test(trimmed)) {
    return { rawUrl: `https://www.youtube.com/${trimmed}`, handle: trimmed };
  }

  let normalized = trimmed;
  if (!/^https?:\/\//i.test(normalized)) {
    normalized = `https://${normalized}`;
  }

  try {
    const url = new URL(normalized);
    const segments = url.pathname.split('/').filter(Boolean);
    if (segments[0]?.startsWith('@')) {
      return { rawUrl: `https://www.youtube.com/${segments[0]}`, handle: segments[0] };
    }
    if (segments[0] === 'channel' && segments[1]) {
      return { rawUrl: `https://www.youtube.com/channel/${segments[1]}`, channelId: segments[1] };
    }
    if (segments[0] === 'user' && segments[1]) {
      return { rawUrl: `https://www.youtube.com/user/${segments[1]}`, username: segments[1] };
    }
    if (segments[0] === 'c' && segments[1]) {
      return { rawUrl: `https://www.youtube.com/c/${segments[1]}`, customPath: segments[1] };
    }
    if (segments[0]) {
      return { rawUrl: normalized, customPath: segments[0] };
    }
    return { rawUrl: normalized };
  } catch {
    return { rawUrl: trimmed };
  }
}

async function fetchWithRetry(
  url: string,
  init: RequestInit = {},
  retries = 2,
  timeoutMs = 10000
): Promise<Response> {
  let lastErr: unknown;
  for (let attempt = 0; attempt <= retries; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const res = await fetch(url, {
        ...init,
        signal: controller.signal,
        headers: {
          'User-Agent': USER_AGENT,
          'Accept-Language': 'en-US,en;q=0.9',
          ...(init.headers || {}),
        },
      });
      clearTimeout(timer);
      if (res.status >= 500 && attempt < retries) {
        await new Promise((r) => setTimeout(r, 400 * (attempt + 1)));
        continue;
      }
      return res;
    } catch (err) {
      clearTimeout(timer);
      lastErr = err;
      if (attempt < retries) {
        await new Promise((r) => setTimeout(r, 400 * (attempt + 1)));
      }
    }
  }
  throw lastErr instanceof Error ? lastErr : new Error('Network request failed');
}

export function parseIsoDuration(iso?: string): { seconds: number | null; formatted: string | null } {
  if (!iso) return { seconds: null, formatted: null };
  const match = iso.match(/^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/);
  if (!match) return { seconds: null, formatted: null };
  const hours = Number(match[1] || 0);
  const mins = Number(match[2] || 0);
  const secs = Number(match[3] || 0);
  const total = hours * 3600 + mins * 60 + secs;
  const pad = (n: number) => String(n).padStart(2, '0');
  const formatted = hours > 0 ? `${hours}:${pad(mins)}:${pad(secs)}` : `${mins}:${pad(secs)}`;
  return { seconds: total, formatted };
}

/**
 * Verifies whether a video ID is genuinely classified as a YouTube Short.
 * Duration <= 60s is used only as a candidate heuristic; YouTube returns HTTP 200
 * on /shorts/<id> for true Shorts and 3xx redirect to /watch for regular videos.
 */
export async function verifyIsShort(videoId: string): Promise<boolean | null> {
  try {
    let res = await fetchWithRetry(
      `https://www.youtube.com/shorts/${encodeURIComponent(videoId)}`,
      { method: 'HEAD', redirect: 'manual' },
      1,
      6000
    );
    if (res.status === 405) {
      res = await fetchWithRetry(
        `https://www.youtube.com/shorts/${encodeURIComponent(videoId)}`,
        { method: 'GET', redirect: 'manual' },
        1,
        6000
      );
    }
    if (res.status === 200) return true;
    if (res.status >= 300 && res.status < 400) return false;
    return null;
  } catch {
    return null;
  }
}

function decodeHtmlEntities(str: string): string {
  return str
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&apos;/g, "'");
}

function extractMetaTag(html: string, attr: string, name: string): string | null {
  const regex = new RegExp(
    `<meta[^>]+${attr}=["']${name}["'][^>]+content=["']([^"']+)["']|<meta[^>]+content=["']([^"']+)["'][^>]+${attr}=["']${name}["']`,
    'i'
  );
  const match = html.match(regex);
  const val = match?.[1] || match?.[2];
  return val ? decodeHtmlEntities(val.trim()) : null;
}

function parseCompactCount(text: string): number | null {
  const clean = text.replace(/subscribers?/i, '').replace(/,/g, '').trim().toUpperCase();
  const match = clean.match(/^([\d.]+)\s*([KMB])?$/);
  if (!match) return null;
  const num = parseFloat(match[1]);
  if (Number.isNaN(num)) return null;
  const mult = match[2] === 'B' ? 1e9 : match[2] === 'M' ? 1e6 : match[2] === 'K' ? 1e3 : 1;
  return Math.round(num * mult);
}

interface PublicChannelMetadata {
  channelId: string | null;
  title: string | null;
  handle: string | null;
  description: string | null;
  avatarUrl: string | null;
  bannerUrl: string | null;
  subscriberDisplay: string | null;
  subscriberCountEstimate: number | null;
}

async function fetchPublicChannelMetadata(target: ParsedChannelTarget): Promise<PublicChannelMetadata> {
  const res = await fetchWithRetry(target.rawUrl, {}, 1, 10000);
  if (!res.ok) {
    throw new Error(`Public channel page returned HTTP ${res.status}`);
  }
  const html = await res.text();

  const canonicalMatch = html.match(/<link[^>]+rel=["']canonical["'][^>]+href=["']([^"']+)["']/i);
  const canonicalUrl = canonicalMatch?.[1] || '';
  const idFromCanonical = canonicalUrl.match(/\/channel\/(UC[\w-]{20,})/)?.[1] || null;
  const idFromJson =
    html.match(/"externalId"\s*:\s*"(UC[\w-]{20,})"/)?.[1] ||
    html.match(/"channelId"\s*:\s*"(UC[\w-]{20,})"/)?.[1] ||
    null;

  const channelId = target.channelId || idFromCanonical || idFromJson;
  const title = extractMetaTag(html, 'property', 'og:title');
  const description = extractMetaTag(html, 'property', 'og:description');
  const avatarUrl = extractMetaTag(html, 'property', 'og:image');

  const handleMatch =
    html.match(/"vanityChannelUrl"\s*:\s*"https?:\/\/(?:www\.)?youtube\.com\/(@[^"]+)"/)?.[1] ||
    target.handle ||
    null;

  const bannerMatch =
    html.match(/"banner"\s*:\s*\{"thumbnails"\s*:\s*\[\{"url"\s*:\s*"([^"]+)"/)?.[1] ||
    html.match(/"tvBanner"\s*:\s*\{"thumbnails"\s*:\s*\[\{"url"\s*:\s*"([^"]+)"/)?.[1] ||
    null;

  const subTextMatch =
    html.match(/"subscriberCountText"\s*:\s*\{"accessibility":\{"accessibilityData":\{"label":"([^"]+)"\}\},"simpleText":"([^"]+)"/) ||
    html.match(/"subscriberCountText"\s*:\s*\{"simpleText":"([^"]+)"\}/) ||
    html.match(/"content"\s*:\s*"([\d.,]+[KMB]?\s+subscribers?)"/i);

  const rawSubDisplay = subTextMatch?.[2] || subTextMatch?.[1] || null;
  const subscriberDisplay = rawSubDisplay ? rawSubDisplay.replace(/\s*subscribers?/i, '').trim() : null;
  const subscriberCountEstimate = subscriberDisplay ? parseCompactCount(subscriberDisplay) : null;

  return {
    channelId,
    title,
    handle: handleMatch,
    description,
    avatarUrl,
    bannerUrl: bannerMatch ? bannerMatch.replace(/\\u0026/g, '&') : null,
    subscriberDisplay,
    subscriberCountEstimate,
  };
}

interface PublicLiveCheckResult {
  isLive: boolean;
  videoId: string | null;
  title: string | null;
  thumbnail: string | null;
  viewers: number | null;
  startedAt: string | null;
}

async function checkPublicLiveStatus(channelId: string): Promise<PublicLiveCheckResult> {
  try {
    const res = await fetchWithRetry(
      `https://www.youtube.com/channel/${encodeURIComponent(channelId)}/live`,
      {},
      1,
      8000
    );
    if (!res.ok) {
      return { isLive: false, videoId: null, title: null, thumbnail: null, viewers: null, startedAt: null };
    }
    const html = await res.text();
    const isLiveNow = /"isLiveNow"\s*:\s*true/.test(html) || /"isLive"\s*:\s*true/.test(html);
    if (!isLiveNow) {
      return { isLive: false, videoId: null, title: null, thumbnail: null, viewers: null, startedAt: null };
    }
    const videoId =
      html.match(/<link[^>]+rel=["']canonical["'][^>]+href=["']https?:\/\/www\.youtube\.com\/watch\?v=([\w-]{11})["']/i)?.[1] ||
      html.match(/"videoId"\s*:\s*"([\w-]{11})"/)?.[1] ||
      null;
    if (!videoId) {
      return { isLive: false, videoId: null, title: null, thumbnail: null, viewers: null, startedAt: null };
    }
    const title = extractMetaTag(html, 'property', 'og:title');
    const thumbnail =
      extractMetaTag(html, 'property', 'og:image') || `https://i.ytimg.com/vi/${videoId}/maxresdefault.jpg`;
    const viewersMatch = html.match(/"concurrentViewers"\s*:\s*"(\d+)"/);
    const startedMatch = html.match(/"startTimestamp"\s*:\s*"([^"]+)"/);

    return {
      isLive: true,
      videoId,
      title,
      thumbnail,
      viewers: viewersMatch ? Number(viewersMatch[1]) : null,
      startedAt: startedMatch ? startedMatch[1] : null,
    };
  } catch {
    return { isLive: false, videoId: null, title: null, thumbnail: null, viewers: null, startedAt: null };
  }
}

interface ParsedFeedVideo {
  id: string;
  title: string;
  description: string;
  thumbnailUrl: string;
  publishedAt: string;
  durationFormatted: string | null;
  durationSeconds: number | null;
  viewCount: number | null;
  isShort: boolean;
  shortChecked: boolean;
  isLivestream: boolean;
  liveStatus: string;
}

function parseDurationTextToSeconds(text: string | null | undefined): number | null {
  if (!text) return null;
  const parts = text.trim().split(':').map((p) => Number(p));
  if (parts.some((n) => Number.isNaN(n))) return null;
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  if (parts.length === 1) return parts[0];
  return null;
}

function parseRelativeTimeEstimate(text: string | null | undefined, fallbackOffsetMs = 0): string {
  const now = Date.now();
  if (!text) return new Date(now - fallbackOffsetMs).toISOString();
  const clean = text.toLowerCase().replace('streamed', '').trim();
  const match = clean.match(/(\d+)\s+(second|minute|hour|day|week|month|year)s?\s+ago/);
  if (!match) return new Date(now - fallbackOffsetMs).toISOString();
  const amount = Number(match[1]);
  const unit = match[2];
  const mult: Record<string, number> = {
    second: 1000,
    minute: 60_000,
    hour: 3_600_000,
    day: 86_400_000,
    week: 604_800_000,
    month: 2_592_000_000,
    year: 31_536_000_000,
  };
  return new Date(now - amount * (mult[unit] || 86_400_000)).toISOString();
}

function parseViewsText(text: string | null | undefined): number | null {
  if (!text) return null;
  const clean = text.replace(/views?/i, '').replace(/,/g, '').trim();
  if (/no views/i.test(clean)) return 0;
  return parseCompactCount(clean);
}

async function fetchPublicRssVideos(channelId: string): Promise<ParsedFeedVideo[]> {
  try {
    const rssUrl = `https://www.youtube.com/feeds/videos.xml?channel_id=${encodeURIComponent(channelId)}`;
    const res = await fetchWithRetry(rssUrl, {}, 0, 7000);
    if (!res.ok) return [];
    const xml = await res.text();
    const entries = xml.match(/<entry>[\s\S]*?<\/entry>/g) || [];
    const results: ParsedFeedVideo[] = [];

    for (const entry of entries) {
      const id = entry.match(/<yt:videoId>([^<]+)<\/yt:videoId>/)?.[1]?.trim();
      const title = decodeHtmlEntities(entry.match(/<title>([\s\S]*?)<\/title>/)?.[1]?.trim() || 'Untitled');
      const publishedAt = entry.match(/<published>([^<]+)<\/published>/)?.[1]?.trim() || new Date().toISOString();
      const description = decodeHtmlEntities(
        entry.match(/<media:description>([\s\S]*?)<\/media:description>/)?.[1]?.trim() || ''
      );
      const thumbnailUrl =
        entry.match(/<media:thumbnail[^>]+url=["']([^"']+)["']/)?.[1] ||
        (id ? `https://i.ytimg.com/vi/${id}/hqdefault.jpg` : '');
      const viewsStr = entry.match(/<media:statistics[^>]+views=["'](\d+)["']/)?.[1];
      const viewCount = viewsStr ? Number(viewsStr) : null;

      if (id) {
        results.push({
          id,
          title,
          description,
          thumbnailUrl,
          publishedAt,
          durationFormatted: null,
          durationSeconds: null,
          viewCount,
          isShort: false,
          shortChecked: false,
          isLivestream: false,
          liveStatus: 'none',
        });
      }
    }
    return results;
  } catch {
    return [];
  }
}

async function fetchPublicTabVideos(
  baseChannelUrl: string,
  tab: 'videos' | 'shorts' | 'streams'
): Promise<ParsedFeedVideo[]> {
  try {
    const cleanBase = baseChannelUrl.replace(/\/+$/, '');
    const res = await fetchWithRetry(`${cleanBase}/${tab}`, {}, 1, 9000);
    if (!res.ok) return [];
    const html = await res.text();
    const match = html.match(/var ytInitialData = (\{[\s\S]*?\});<\/script>/);
    if (!match) return [];

    const data = JSON.parse(match[1]) as Record<string, any>;
    const tabs = data?.contents?.twoColumnBrowseResultsRenderer?.tabs || [];
    const activeTab = tabs.find((t: any) => t.tabRenderer?.selected);
    const items = activeTab?.tabRenderer?.content?.richGridRenderer?.contents || [];
    const parsed: ParsedFeedVideo[] = [];

    items.forEach((entry: any, idx: number) => {
      const content = entry?.richItemRenderer?.content;
      if (!content) return;

      if (tab === 'shorts' && content.shortsLockupViewModel) {
        const vm = content.shortsLockupViewModel;
        const vidId = vm.onTap?.innertubeCommand?.reelWatchEndpoint?.videoId as string | undefined;
        if (!vidId) return;
        const thumb =
          vm.onTap?.innertubeCommand?.reelWatchEndpoint?.thumbnail?.thumbnails?.[0]?.url ||
          `https://i.ytimg.com/vi/${vidId}/frame0.jpg`;
        const primaryTitle =
          vm.overlayMetadata?.primaryText?.content ||
          (typeof vm.accessibilityText === 'string'
            ? vm.accessibilityText.replace(/,\s*[\d.,]+\s*\w*\s*views?\s*-\s*play Short$/i, '').trim()
            : 'YouTube Short');
        const viewsText = vm.overlayMetadata?.secondaryText?.content || vm.accessibilityText;
        const viewsMatch = typeof viewsText === 'string' ? viewsText.match(/([\d.,]+\s*(?:thousand|million|K|M|B)?\s*views?)/i)?.[1] : null;
        let viewCount: number | null = null;
        if (viewsMatch) {
          const normalized = viewsMatch.replace(/thousand/i, 'K').replace(/million/i, 'M');
          viewCount = parseViewsText(normalized);
        }

        parsed.push({
          id: vidId,
          title: primaryTitle || 'YouTube Short',
          description: '',
          thumbnailUrl: thumb,
          publishedAt: new Date(Date.now() - idx * 3600_000).toISOString(),
          durationFormatted: null,
          durationSeconds: null,
          viewCount,
          isShort: true,
          shortChecked: true,
          isLivestream: false,
          liveStatus: 'none',
        });
        return;
      }

      if (content.lockupViewModel) {
        const vm = content.lockupViewModel;
        const vidId = vm.contentId as string | undefined;
        if (!vidId) return;
        const sources = vm.contentImage?.thumbnailViewModel?.image?.sources || [];
        const thumb = sources[sources.length - 1]?.url || `https://i.ytimg.com/vi/${vidId}/hqdefault.jpg`;
        const durationBadge =
          vm.contentImage?.thumbnailViewModel?.overlays?.[0]?.thumbnailBottomOverlayViewModel?.badges?.[0]
            ?.thumbnailBadgeViewModel?.text || null;
        const isLiveNowBadge = typeof durationBadge === 'string' && /live/i.test(durationBadge);
        const durationFormatted = durationBadge && !isLiveNowBadge ? durationBadge : null;
        const durationSeconds = parseDurationTextToSeconds(durationFormatted);
        const title = vm.metadata?.lockupMetadataViewModel?.title?.content || 'Untitled Video';
        const rows = vm.metadata?.lockupMetadataViewModel?.metadata?.contentMetadataViewModel?.metadataRows || [];
        const parts: string[] = [];
        for (const r of rows) {
          for (const p of r.metadataParts || []) {
            if (p.text?.content) parts.push(p.text.content);
          }
        }
        const viewPart = parts.find((p) => /views?/i.test(p));
        const datePart = parts.find((p) => /ago/i.test(p));

        parsed.push({
          id: vidId,
          title,
          description: '',
          thumbnailUrl: thumb,
          publishedAt: parseRelativeTimeEstimate(datePart, idx * 86_400_000),
          durationFormatted,
          durationSeconds,
          viewCount: parseViewsText(viewPart),
          isShort: false,
          shortChecked: true,
          isLivestream: tab === 'streams',
          liveStatus: tab === 'streams' ? (isLiveNowBadge ? 'live' : 'completed') : 'none',
        });
        return;
      }

      if (content.videoRenderer) {
        const vr = content.videoRenderer;
        const vidId = vr.videoId as string | undefined;
        if (!vidId) return;
        const thumbs = vr.thumbnail?.thumbnails || [];
        const thumb = thumbs[thumbs.length - 1]?.url || `https://i.ytimg.com/vi/${vidId}/hqdefault.jpg`;
        const title = vr.title?.runs?.[0]?.text || vr.title?.simpleText || 'Untitled Video';
        const durationFormatted = vr.lengthText?.simpleText || null;
        const durationSeconds = parseDurationTextToSeconds(durationFormatted);
        const viewText = vr.viewCountText?.simpleText || vr.shortViewCountText?.simpleText;
        const dateText = vr.publishedTimeText?.simpleText;

        parsed.push({
          id: vidId,
          title,
          description: '',
          thumbnailUrl: thumb,
          publishedAt: parseRelativeTimeEstimate(dateText, idx * 86_400_000),
          durationFormatted,
          durationSeconds,
          viewCount: parseViewsText(viewText),
          isShort: false,
          shortChecked: true,
          isLivestream: tab === 'streams',
          liveStatus: tab === 'streams' ? 'completed' : 'none',
        });
      }
    });

    return parsed;
  } catch {
    return [];
  }
}

async function fetchYouTubeJson(endpoint: string, params: Record<string, string>, apiKey: string) {
  const qs = new URLSearchParams({ ...params, key: apiKey });
  const res = await fetchWithRetry(`${YOUTUBE_API_BASE}/${endpoint}?${qs.toString()}`, {}, 2, 10000);
  const data = (await res.json()) as Record<string, any>;
  if (!res.ok || data.error) {
    const msg = data?.error?.message || `YouTube API HTTP ${res.status}`;
    throw new Error(msg);
  }
  return data;
}

async function syncViaOfficialApi(
  target: ParsedChannelTarget,
  apiKey: string,
  syncType: 'all' | 'subscribers' | 'videos' | 'live'
) {
  const site = getSiteConfig();
  let channelId = target.channelId || site.channel_id;

  const channelParams: Record<string, string> = {
    part: 'snippet,contentDetails,statistics,brandingSettings',
  };
  if (channelId) {
    channelParams.id = channelId;
  } else if (target.handle) {
    channelParams.forHandle = target.handle;
  } else if (target.username) {
    channelParams.forUsername = target.username;
  } else {
    const pub = await fetchPublicChannelMetadata(target);
    if (!pub.channelId) {
      throw new Error('Could not resolve YouTube Channel ID from the supplied URL.');
    }
    channelId = pub.channelId;
    channelParams.id = channelId;
  }

  const chResp = await fetchYouTubeJson('channels', channelParams, apiKey);
  const chItem = chResp.items?.[0];
  if (!chItem) {
    throw new Error('YouTube channel not found via official YouTube Data API v3.');
  }

  const resolvedChannelId = chItem.id as string;
  const snippet = chItem.snippet || {};
  const statistics = chItem.statistics || {};
  const branding = chItem.brandingSettings || {};
  const uploadsPlaylistId = chItem.contentDetails?.relatedPlaylists?.uploads as string | undefined;

  const now = new Date().toISOString();
  const avatarUrl =
    snippet.thumbnails?.high?.url || snippet.thumbnails?.medium?.url || snippet.thumbnails?.default?.url || null;
  const bannerUrl = branding.image?.bannerExternalUrl || null;
  const handle = snippet.customUrl || target.handle || site.channel_handle;

  db.prepare(`
    UPDATE site_config
    SET channel_id = ?,
        channel_handle = COALESCE(?, channel_handle),
        avatar_url = COALESCE(?, avatar_url),
        banner_url = COALESCE(?, banner_url),
        channel_description = CASE WHEN ? != '' THEN ? ELSE channel_description END,
        updated_at = ?
    WHERE id = 1
  `).run(
    resolvedChannelId,
    handle,
    avatarUrl,
    bannerUrl,
    snippet.description || '',
    snippet.description || '',
    now
  );

  if (syncType === 'all' || syncType === 'subscribers') {
    const hidden = Boolean(statistics.hiddenSubscriberCount);
    const subCount = !hidden && statistics.subscriberCount !== undefined ? Number(statistics.subscriberCount) : null;
    const viewCount = statistics.viewCount !== undefined ? Number(statistics.viewCount) : null;
    const videoCount = statistics.videoCount !== undefined ? Number(statistics.videoCount) : null;

    db.prepare(`
      UPDATE channel_stats
      SET subscriber_count = ?,
          subscriber_display = ?,
          hidden_subscriber_count = ?,
          subscriber_source = ?,
          subscriber_unavailable_reason = ?,
          view_count = ?,
          video_count = ?,
          last_subscriber_sync = ?,
          last_error = NULL
      WHERE id = 1
    `).run(
      subCount,
      subCount !== null ? subCount.toLocaleString('en-US') : null,
      hidden ? 1 : 0,
      hidden ? 'hidden' : 'youtube-api',
      hidden ? 'This creator has hidden their public subscriber count on YouTube.' : null,
      viewCount,
      videoCount,
      now
    );
  }

  if ((syncType === 'all' || syncType === 'videos') && uploadsPlaylistId) {
    const plResp = await fetchYouTubeJson(
      'playlistItems',
      {
        part: 'contentDetails,snippet',
        playlistId: uploadsPlaylistId,
        maxResults: '40',
      },
      apiKey
    );

    const videoIds: string[] = (plResp.items || [])
      .map((item: any) => item.contentDetails?.videoId as string)
      .filter(Boolean);

    if (videoIds.length > 0) {
      const vidResp = await fetchYouTubeJson(
        'videos',
        {
          part: 'snippet,contentDetails,statistics,liveStreamingDetails',
          id: videoIds.join(','),
        },
        apiKey
      );

      const upsertStmt = db.prepare(`
        INSERT INTO videos (
          id, title, description, thumbnail_url, published_at,
          duration_seconds, duration_formatted, view_count, like_count,
          category, is_short, short_checked, is_livestream, live_status, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
          title = excluded.title,
          description = excluded.description,
          thumbnail_url = excluded.thumbnail_url,
          published_at = excluded.published_at,
          duration_seconds = excluded.duration_seconds,
          duration_formatted = excluded.duration_formatted,
          view_count = excluded.view_count,
          like_count = excluded.like_count,
          is_livestream = excluded.is_livestream,
          live_status = excluded.live_status,
          is_short = CASE WHEN videos.short_checked = 1 THEN videos.is_short ELSE excluded.is_short END,
          short_checked = CASE WHEN videos.short_checked = 1 THEN 1 ELSE excluded.short_checked END,
          updated_at = excluded.updated_at
      `);

      const existingMap = new Map<string, { short_checked: number; is_short: number }>();
      const existingRows = db.prepare('SELECT id, short_checked, is_short FROM videos').all() as Array<{
        id: string;
        short_checked: number;
        is_short: number;
      }>;
      for (const r of existingRows) {
        existingMap.set(r.id, r);
      }

      let checksInBatch = 0;
      for (const v of vidResp.items || []) {
        const vidId = v.id as string;
        const vSnippet = v.snippet || {};
        const vContent = v.contentDetails || {};
        const vStats = v.statistics || {};
        const liveDetails = v.liveStreamingDetails;

        const { seconds, formatted } = parseIsoDuration(vContent.duration);
        const thumb =
          vSnippet.thumbnails?.maxres?.url ||
          vSnippet.thumbnails?.high?.url ||
          vSnippet.thumbnails?.medium?.url ||
          `https://i.ytimg.com/vi/${vidId}/hqdefault.jpg`;

        const isLivestream = liveDetails ? 1 : 0;
        let liveStatus = 'none';
        if (vSnippet.liveBroadcastContent === 'live') liveStatus = 'live';
        else if (vSnippet.liveBroadcastContent === 'upcoming') liveStatus = 'upcoming';
        else if (liveDetails?.actualEndTime) liveStatus = 'completed';

        const cached = existingMap.get(vidId);
        let isShort = cached?.is_short ?? 0;
        let shortChecked = cached?.short_checked ?? 0;

        if (!shortChecked && seconds !== null && seconds <= 65 && !isLivestream && checksInBatch < 10) {
          checksInBatch++;
          const verified = await verifyIsShort(vidId);
          if (verified !== null) {
            isShort = verified ? 1 : 0;
            shortChecked = 1;
          }
        } else if (!shortChecked && seconds !== null && seconds > 65) {
          isShort = 0;
          shortChecked = 1;
        }

        const category = isShort ? 'Short' : isLivestream ? 'Livestream' : 'Upload';

        upsertStmt.run(
          vidId,
          vSnippet.title || 'Untitled Video',
          vSnippet.description || '',
          thumb,
          vSnippet.publishedAt || now,
          seconds,
          formatted,
          vStats.viewCount !== undefined ? Number(vStats.viewCount) : null,
          vStats.likeCount !== undefined ? Number(vStats.likeCount) : null,
          category,
          isShort,
          shortChecked,
          isLivestream,
          liveStatus,
          now
        );
      }

      db.prepare('UPDATE channel_stats SET last_video_sync = ?, last_error = NULL WHERE id = 1').run(now);
    }
  }

  if (syncType === 'all' || syncType === 'live') {
    const liveSearch = await fetchYouTubeJson(
      'search',
      {
        part: 'snippet',
        channelId: resolvedChannelId,
        eventType: 'live',
        type: 'video',
        maxResults: '1',
      },
      apiKey
    );

    const activeItem = liveSearch.items?.[0];
    let isLive = 0;
    let liveVideoId: string | null = null;
    let liveTitle: string | null = null;
    let liveThumbnail: string | null = null;
    let liveStartedAt: string | null = null;
    let liveViewers: number | null = null;

    if (activeItem?.id?.videoId) {
      liveVideoId = activeItem.id.videoId as string;
      const liveDetailsResp = await fetchYouTubeJson(
        'videos',
        { part: 'snippet,liveStreamingDetails', id: liveVideoId },
        apiKey
      );
      const liveVid = liveDetailsResp.items?.[0];
      if (liveVid && liveVid.snippet?.liveBroadcastContent === 'live') {
        isLive = 1;
        liveTitle = liveVid.snippet?.title || activeItem.snippet?.title || 'Live Stream';
        liveThumbnail =
          liveVid.snippet?.thumbnails?.maxres?.url ||
          liveVid.snippet?.thumbnails?.high?.url ||
          `https://i.ytimg.com/vi/${liveVideoId}/maxresdefault.jpg`;
        liveStartedAt = liveVid.liveStreamingDetails?.actualStartTime || null;
        liveViewers =
          liveVid.liveStreamingDetails?.concurrentViewers !== undefined
            ? Number(liveVid.liveStreamingDetails.concurrentViewers)
            : null;
      }
    }

    let upcomingList: Array<{ id: string; title: string; thumbnail: string; scheduledStartTime: string | null }> = [];
    try {
      const upcomingResp = await fetchYouTubeJson(
        'search',
        {
          part: 'snippet',
          channelId: resolvedChannelId,
          eventType: 'upcoming',
          type: 'video',
          maxResults: '3',
        },
        apiKey
      );
      const upIds = (upcomingResp.items || []).map((i: any) => i.id?.videoId).filter(Boolean);
      if (upIds.length > 0) {
        const upVideos = await fetchYouTubeJson(
          'videos',
          { part: 'snippet,liveStreamingDetails', id: upIds.join(',') },
          apiKey
        );
        upcomingList = (upVideos.items || []).map((u: any) => ({
          id: u.id,
          title: u.snippet?.title || 'Upcoming Stream',
          thumbnail: u.snippet?.thumbnails?.high?.url || `https://i.ytimg.com/vi/${u.id}/hqdefault.jpg`,
          scheduledStartTime: u.liveStreamingDetails?.scheduledStartTime || null,
        }));
      }
    } catch {
      // Non-critical upcoming check
    }

    db.prepare(`
      UPDATE channel_stats
      SET is_live = ?,
          live_video_id = ?,
          live_title = ?,
          live_thumbnail = ?,
          live_started_at = ?,
          live_viewers = ?,
          upcoming_live_json = ?,
          last_live_sync = ?,
          last_error = NULL
      WHERE id = 1
    `).run(
      isLive,
      liveVideoId,
      liveTitle,
      liveThumbnail,
      liveStartedAt,
      liveViewers,
      JSON.stringify(upcomingList),
      now
    );
  }
}

async function syncViaPublicFallback(
  target: ParsedChannelTarget,
  syncType: 'all' | 'subscribers' | 'videos' | 'live'
) {
  const site = getSiteConfig();
  const now = new Date().toISOString();

  const meta = await fetchPublicChannelMetadata(target);
  const resolvedChannelId = meta.channelId || site.channel_id;
  const tabBaseUrl =
    meta.handle && meta.handle.startsWith('@')
      ? `https://www.youtube.com/${meta.handle}`
      : resolvedChannelId
        ? `https://www.youtube.com/channel/${resolvedChannelId}`
        : target.rawUrl;

  db.prepare(`
    UPDATE site_config
    SET channel_id = COALESCE(?, channel_id),
        channel_handle = COALESCE(?, channel_handle),
        avatar_url = COALESCE(?, avatar_url),
        banner_url = COALESCE(?, banner_url),
        channel_description = CASE WHEN ? IS NOT NULL AND ? != '' THEN ? ELSE channel_description END,
        updated_at = ?
    WHERE id = 1
  `).run(
    resolvedChannelId,
    meta.handle,
    meta.avatarUrl,
    meta.bannerUrl,
    meta.description,
    meta.description,
    meta.description,
    now
  );

  if (syncType === 'all' || syncType === 'subscribers') {
    const hasPublicDisplay = Boolean(meta.subscriberDisplay);
    db.prepare(`
      UPDATE channel_stats
      SET subscriber_count = ?,
          subscriber_display = ?,
          hidden_subscriber_count = 0,
          subscriber_source = ?,
          subscriber_unavailable_reason = ?,
          last_subscriber_sync = ?,
          last_error = NULL
      WHERE id = 1
    `).run(
      meta.subscriberCountEstimate,
      meta.subscriberDisplay,
      hasPublicDisplay ? 'public-feed' : 'unavailable',
      hasPublicDisplay
        ? 'Public channel display estimate. Configure YOUTUBE_API_KEY for official YouTube Data API v3 statistics.'
        : 'Subscriber count is currently unavailable without a configured YouTube Data API v3 key.',
      now
    );
  }

  if ((syncType === 'all' || syncType === 'videos') && resolvedChannelId) {
    const [rssVideos, tabVideos, tabShorts, tabStreams] = await Promise.all([
      fetchPublicRssVideos(resolvedChannelId),
      fetchPublicTabVideos(tabBaseUrl, 'videos'),
      fetchPublicTabVideos(tabBaseUrl, 'shorts'),
      fetchPublicTabVideos(tabBaseUrl, 'streams'),
    ]);

    const mergedMap = new Map<string, ParsedFeedVideo>();
    // Prefer tab metadata for duration/isShort/isLivestream, enrich with RSS exact ISO timestamps & descriptions
    for (const v of [...tabVideos, ...tabStreams, ...tabShorts]) {
      mergedMap.set(v.id, v);
    }
    for (const r of rssVideos) {
      const existing = mergedMap.get(r.id);
      if (existing) {
        mergedMap.set(r.id, {
          ...existing,
          publishedAt: r.publishedAt || existing.publishedAt,
          description: r.description || existing.description,
          viewCount: existing.viewCount ?? r.viewCount,
        });
      } else {
        mergedMap.set(r.id, r);
      }
    }

    const mergedVideos = Array.from(mergedMap.values());
    if (mergedVideos.length === 0) {
      throw new Error('Could not retrieve public uploads or Shorts from YouTube channel.');
    }

    const existingMap = new Map<string, { short_checked: number; is_short: number }>();
    const existingRows = db.prepare('SELECT id, short_checked, is_short FROM videos').all() as Array<{
      id: string;
      short_checked: number;
      is_short: number;
    }>;
    for (const r of existingRows) {
      existingMap.set(r.id, r);
    }

    // Verify any unverified RSS-only items via /shorts/<id>
    const toVerify = mergedVideos.filter((v) => !v.shortChecked && !existingMap.get(v.id)?.short_checked).slice(0, 15);
    const verifiedResults = new Map<string, boolean | null>();
    for (let i = 0; i < toVerify.length; i += 5) {
      const chunk = toVerify.slice(i, i + 5);
      const outcomes = await Promise.all(chunk.map(async (item) => [item.id, await verifyIsShort(item.id)] as const));
      for (const [id, ok] of outcomes) {
        verifiedResults.set(id, ok);
      }
    }

    const upsertStmt = db.prepare(`
      INSERT INTO videos (
        id, title, description, thumbnail_url, published_at,
        duration_seconds, duration_formatted, view_count, category,
        is_short, short_checked, is_livestream, live_status, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET
        title = excluded.title,
        description = CASE WHEN excluded.description != '' THEN excluded.description ELSE videos.description END,
        thumbnail_url = excluded.thumbnail_url,
        published_at = excluded.published_at,
        duration_seconds = COALESCE(excluded.duration_seconds, videos.duration_seconds),
        duration_formatted = COALESCE(excluded.duration_formatted, videos.duration_formatted),
        view_count = COALESCE(excluded.view_count, videos.view_count),
        is_livestream = CASE WHEN excluded.is_livestream = 1 THEN 1 ELSE videos.is_livestream END,
        live_status = CASE WHEN excluded.live_status != 'none' THEN excluded.live_status ELSE videos.live_status END,
        is_short = CASE WHEN excluded.short_checked = 1 THEN excluded.is_short ELSE videos.is_short END,
        short_checked = CASE WHEN excluded.short_checked = 1 THEN 1 ELSE videos.short_checked END,
        category = excluded.category,
        updated_at = excluded.updated_at
    `);

    for (const v of mergedVideos) {
      const cached = existingMap.get(v.id);
      let isShort = v.isShort ? 1 : cached?.is_short ?? 0;
      let shortChecked = v.shortChecked ? 1 : cached?.short_checked ?? 0;

      if (!shortChecked && verifiedResults.has(v.id)) {
        const verified = verifiedResults.get(v.id);
        if (verified !== null && verified !== undefined) {
          isShort = verified ? 1 : 0;
          shortChecked = 1;
        }
      }

      const category = isShort ? 'Short' : v.isLivestream ? 'Livestream' : 'Upload';
      upsertStmt.run(
        v.id,
        v.title,
        v.description,
        v.thumbnailUrl,
        v.publishedAt,
        v.durationSeconds,
        v.durationFormatted,
        v.viewCount,
        category,
        isShort,
        shortChecked,
        v.isLivestream ? 1 : 0,
        v.liveStatus,
        now
      );
    }

    db.prepare('UPDATE channel_stats SET last_video_sync = ?, last_error = NULL WHERE id = 1').run(now);
  }

  if ((syncType === 'all' || syncType === 'live') && resolvedChannelId) {
    const live = await checkPublicLiveStatus(resolvedChannelId);
    db.prepare(`
      UPDATE channel_stats
      SET is_live = ?,
          live_video_id = ?,
          live_title = ?,
          live_thumbnail = ?,
          live_started_at = ?,
          live_viewers = ?,
          last_live_sync = ?,
          last_error = NULL
      WHERE id = 1
    `).run(
      live.isLive ? 1 : 0,
      live.videoId,
      live.title,
      live.thumbnail,
      live.startedAt,
      live.viewers,
      now
    );
  }
}

export async function syncYouTubeChannel(
  syncType: 'all' | 'subscribers' | 'videos' | 'live' = 'all'
): Promise<{ success: boolean; mode: 'youtube-api' | 'public-feed'; error?: string }> {
  const site = getSiteConfig();
  const target = parseYouTubeChannelUrl(site.youtube_channel_url);
  const apiKey = process.env.YOUTUBE_API_KEY?.trim();

  if (apiKey) {
    try {
      await syncViaOfficialApi(target, apiKey, syncType);
      addSyncLog(syncType, 'ok', 'Synced via official YouTube Data API v3');
      return { success: true, mode: 'youtube-api' };
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'YouTube Data API error';
      addSyncLog(syncType, 'warn', `YouTube Data API fallback triggered: ${msg}`);
      // Attempt public fallback while preserving last valid data if fallback also fails
      try {
        await syncViaPublicFallback(target, syncType);
        addSyncLog(syncType, 'ok', 'Synced via public YouTube feed fallback');
        return { success: true, mode: 'public-feed', error: msg };
      } catch (fallbackErr) {
        const fbMsg = fallbackErr instanceof Error ? fallbackErr.message : 'Sync failed';
        db.prepare('UPDATE channel_stats SET last_error = ? WHERE id = 1').run(`${msg} | ${fbMsg}`);
        addSyncLog(syncType, 'error', fbMsg);
        return { success: false, mode: 'youtube-api', error: msg };
      }
    }
  }

  try {
    await syncViaPublicFallback(target, syncType);
    addSyncLog(syncType, 'ok', 'Synced via public YouTube feed & channel metadata');
    return { success: true, mode: 'public-feed' };
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Unable to reach YouTube public feed';
    const currentStats = getChannelStats();
    db.prepare('UPDATE channel_stats SET last_error = ?, subscriber_source = COALESCE(subscriber_source, ?) WHERE id = 1').run(
      msg,
      currentStats.subscriber_source || 'unavailable'
    );
    addSyncLog(syncType, 'error', msg);
    return { success: false, mode: 'public-feed', error: msg };
  }
}
