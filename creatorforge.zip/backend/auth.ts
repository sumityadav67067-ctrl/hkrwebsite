import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import type { NextFunction, Request, Response } from 'express';
import { db } from './db.ts';

export const SESSION_COOKIE_NAME = 'cf_admin_session';
const SESSION_TTL_MS = 24 * 60 * 60 * 1000;

export function hasAnyAdminUser(): boolean {
  const row = db.prepare('SELECT COUNT(*) as count FROM admin_users').get() as { count: number };
  return row.count > 0;
}

export function bootstrapAdminFromEnvIfConfigured(): void {
  if (hasAnyAdminUser()) return;
  const envPass = process.env.ADMIN_PASSWORD?.trim();
  const envUser = (process.env.ADMIN_USERNAME || 'admin').trim();
  if (!envPass || envPass.length < 8) {
    return;
  }
  const hash = bcrypt.hashSync(envPass, 10);
  db.prepare('INSERT INTO admin_users (username, password_hash, created_at) VALUES (?, ?, ?)').run(
    envUser,
    hash,
    new Date().toISOString()
  );
}

export function createAdminUser(username: string, password: string): { id: number; username: string } {
  const cleanUser = username.trim().toLowerCase();
  const hash = bcrypt.hashSync(password, 10);
  const now = new Date().toISOString();
  const result = db
    .prepare('INSERT INTO admin_users (username, password_hash, created_at) VALUES (?, ?, ?)')
    .run(cleanUser, hash, now);
  return { id: Number(result.lastInsertRowid), username: cleanUser };
}

export function verifyAdminCredentials(
  username: string,
  password: string
): { id: number; username: string } | null {
  const cleanUser = username.trim().toLowerCase();
  const row = db
    .prepare('SELECT id, username, password_hash FROM admin_users WHERE lower(username) = ?')
    .get(cleanUser) as { id: number; username: string; password_hash: string } | undefined;

  if (!row) return null;
  if (!bcrypt.compareSync(password, row.password_hash)) return null;
  return { id: row.id, username: row.username };
}

export function createSession(userId: number): { token: string; csrfToken: string; expiresAt: string } {
  const token = crypto.randomBytes(32).toString('hex');
  const csrfToken = crypto.randomBytes(24).toString('hex');
  const now = Date.now();
  const expiresAt = new Date(now + SESSION_TTL_MS).toISOString();

  db.prepare('DELETE FROM admin_sessions WHERE expires_at < ?').run(new Date().toISOString());
  db.prepare(
    'INSERT INTO admin_sessions (token, csrf_token, user_id, expires_at, created_at) VALUES (?, ?, ?, ?, ?)'
  ).run(token, csrfToken, userId, expiresAt, new Date(now).toISOString());

  return { token, csrfToken, expiresAt };
}

export function getSession(token: string | undefined): {
  token: string;
  csrfToken: string;
  userId: number;
  username: string;
} | null {
  if (!token) return null;
  const row = db
    .prepare(
      `SELECT s.token, s.csrf_token, s.user_id, s.expires_at, u.username
       FROM admin_sessions s
       JOIN admin_users u ON u.id = s.user_id
       WHERE s.token = ?`
    )
    .get(token) as
    | { token: string; csrf_token: string; user_id: number; expires_at: string; username: string }
    | undefined;

  if (!row) return null;
  if (new Date(row.expires_at).getTime() < Date.now()) {
    db.prepare('DELETE FROM admin_sessions WHERE token = ?').run(token);
    return null;
  }
  return {
    token: row.token,
    csrfToken: row.csrf_token,
    userId: row.user_id,
    username: row.username,
  };
}

export function deleteSession(token: string | undefined): void {
  if (!token) return;
  db.prepare('DELETE FROM admin_sessions WHERE token = ?').run(token);
}

export interface AuthenticatedRequest extends Request {
  adminUser?: { id: number; username: string; csrfToken: string };
}

export function requireAdmin(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const token = req.cookies?.[SESSION_COOKIE_NAME] as string | undefined;
  const session = getSession(token);
  if (!session) {
    res.status(401).json({ error: 'Authentication required.' });
    return;
  }

  const method = req.method.toUpperCase();
  if (method !== 'GET' && method !== 'HEAD' && method !== 'OPTIONS') {
    const headerCsrf = req.get('x-csrf-token');
    if (!headerCsrf || headerCsrf !== session.csrfToken) {
      res.status(403).json({ error: 'Invalid CSRF token.' });
      return;
    }
  }

  req.adminUser = {
    id: session.userId,
    username: session.username,
    csrfToken: session.csrfToken,
  };
  next();
}
