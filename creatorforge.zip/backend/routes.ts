import express, { type Request, type Response } from 'express';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';
import {
  createAdminUser,
  createSession,
  deleteSession,
  getSession,
  hasAnyAdminUser,
  requireAdmin,
  SESSION_COOKIE_NAME,
  verifyAdminCredentials,
  type AuthenticatedRequest,
} from './auth.ts';
import { generateAndApplyChannelBranding } from './brandingService.ts';
import { db, getChannelStats, getSiteConfig, type SiteConfigRow, type VideoRow } from './db.ts';
import { broadcastSseEvent, registerSseClient, runSyncTask } from './syncWorker.ts';

function serializeSite(row: SiteConfigRow) {
  let categories: string[] = [];
  let socialLinks: Record<string, string> = {};
  try {
    categories = JSON.parse(row.categories_json || '[]');
  } catch {
    categories = [];
  }
  try {
    socialLinks = JSON.parse(row.social_links_json || '{}');
  } catch {
    socialLinks = {};
  }

  return {
    channelName: row.channel_name,
    youtubeChannelUrl: row.youtube_channel_url,
    discordInviteUrl: row.discord_invite_url,
    desiredPort: row.desired_port,
    channelId: row.channel_id,
    channelHandle: row.channel_handle,
    avatarUrl: row.avatar_url,
    bannerUrl: row.banner_url,
    channelDescription: row.channel_description,
    niche: row.niche,
    categories,
    heroHeadline: row.hero_headline,
    heroSubheadline: row.hero_subheadline,
    aboutText: row.about_text,
    communityPitch: row.community_pitch,
    themeMode: row.theme_mode,
    primaryColor: row.primary_color,
    secondaryColor: row.secondary_color,
    accentColor: row.accent_color,
    fontDisplay: row.font_display,
    fontBody: row.font_body,
    socialLinks,
    featuredVideoId: row.featured_video_id,
    updatedAt: row.updated_at,
  };
}

function serializeStats() {
  const row = getChannelStats();
  let upcomingLive: Array<{ id: string; title: string; thumbnail: string; scheduledStartTime: string | null }> = [];
  try {
    upcomingLive = JSON.parse(row.upcoming_live_json || '[]');
  } catch {
    upcomingLive = [];
  }

  return {
    subscriberCount: row.subscriber_count,
    subscriberDisplay: row.subscriber_display,
    hiddenSubscriberCount: Boolean(row.hidden_subscriber_count),
    subscriberSource: row.subscriber_source,
    subscriberUnavailableReason: row.subscriber_unavailable_reason,
    viewCount: row.view_count,
    videoCount: row.video_count,
    isLive: Boolean(row.is_live),
    liveVideoId: row.live_video_id,
    liveTitle: row.live_title,
    liveThumbnail: row.live_thumbnail,
    liveStartedAt: row.live_started_at,
    liveViewers: row.live_viewers,
    upcomingLive,
    lastSubscriberSync: row.last_subscriber_sync,
    lastVideoSync: row.last_video_sync,
    lastLiveSync: row.last_live_sync,
    lastError: row.last_error,
  };
}

function serializeVideo(v: VideoRow) {
  return {
    id: v.id,
    title: v.title,
    description: v.description,
    thumbnailUrl: v.thumbnail_url,
    publishedAt: v.published_at,
    durationSeconds: v.duration_seconds,
    durationFormatted: v.duration_formatted,
    viewCount: v.view_count,
    likeCount: v.like_count,
    category: v.category,
    isShort: Boolean(v.is_short),
    isLivestream: Boolean(v.is_livestream),
    liveStatus: v.live_status,
    isFeatured: Boolean(v.is_featured),
  };
}

function buildDeploymentSnippets(site: SiteConfigRow) {
  const port = site.desired_port || 25595;
  const envFile = [
    `PORT=${port}`,
    `HOST=0.0.0.0`,
    `DESIRED_PORT=${port}`,
    `CHANNEL_NAME="${site.channel_name.replace(/"/g, '\\"')}"`,
    `YOUTUBE_CHANNEL_URL="${site.youtube_channel_url}"`,
    `DISCORD_INVITE_URL="${site.discord_invite_url}"`,
    `YOUTUBE_API_KEY="YOUR_YOUTUBE_DATA_API_V3_KEY"`,
    `GEMINI_API_KEY="YOUR_GEMINI_API_KEY"`,
    `CACHE_TTL=300000`,
    `SUBSCRIBER_REFRESH_INTERVAL=300000`,
    `VIDEO_REFRESH_INTERVAL=600000`,
    `LIVE_REFRESH_INTERVAL=120000`,
    `APP_URL="http://localhost:${port}"`,
  ].join('\n');

  const pm2Config = `module.exports = {
  apps: [
    {
      name: "${site.channel_name.toLowerCase().replace(/[^a-z0-9]+/g, '-') || 'creator-website'}",
      script: "server.js",
      instances: 1,
      autorestart: true,
      watch: false,
      env: {
        NODE_ENV: "production",
        PORT: ${port},
        HOST: "0.0.0.0"
      }
    }
  ]
};`;

  return { envFile, pm2Config, port };
}

export function createApiRouter() {
  const router = express.Router();

  const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 30,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Too many authentication attempts. Please wait 15 minutes.' },
  });

  const contactLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 10,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Rate limit exceeded for contact submissions. Please try again shortly.' },
  });

  const setupLimiter = rateLimit({
    windowMs: 10 * 60 * 1000,
    limit: 15,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Too many site generation requests. Please wait a few minutes.' },
  });

  router.get('/health', (_req: Request, res: Response) => {
    res.json({
      status: 'ok',
      port: Number(process.env.PORT) || 3000,
      uptimeSeconds: Math.round(process.uptime()),
      timestamp: new Date().toISOString(),
    });
  });

  router.get('/events', (req: Request, res: Response) => {
    registerSseClient(res);
  });

  router.get('/site', (_req: Request, res: Response) => {
    const siteRow = getSiteConfig();
    const stats = serializeStats();

    let featuredRow = siteRow.featured_video_id
      ? (db.prepare('SELECT * FROM videos WHERE id = ?').get(siteRow.featured_video_id) as VideoRow | undefined)
      : (db.prepare('SELECT * FROM videos WHERE is_featured = 1 ORDER BY published_at DESC LIMIT 1').get() as
          | VideoRow
          | undefined);

    if (!featuredRow) {
      featuredRow = db
        .prepare('SELECT * FROM videos WHERE is_short = 0 ORDER BY published_at DESC LIMIT 1')
        .get() as VideoRow | undefined;
    }

    const latestVideos = (
      db.prepare('SELECT * FROM videos WHERE is_short = 0 ORDER BY published_at DESC LIMIT 8').all() as VideoRow[]
    ).map(serializeVideo);

    const popularVideos = (
      db
        .prepare(
          'SELECT * FROM videos WHERE is_short = 0 ORDER BY COALESCE(view_count, 0) DESC, published_at DESC LIMIT 6'
        )
        .all() as VideoRow[]
    ).map(serializeVideo);

    const latestShorts = (
      db.prepare('SELECT * FROM videos WHERE is_short = 1 ORDER BY published_at DESC LIMIT 8').all() as VideoRow[]
    ).map(serializeVideo);

    const recentLivestreams = (
      db
        .prepare(
          "SELECT * FROM videos WHERE is_livestream = 1 AND live_status != 'live' ORDER BY published_at DESC LIMIT 6"
        )
        .all() as VideoRow[]
    ).map(serializeVideo);

    res.json({
      site: serializeSite(siteRow),
      stats,
      featuredVideo: featuredRow ? serializeVideo(featuredRow) : null,
      latestVideos,
      popularVideos,
      latestShorts,
      recentLivestreams,
      configStatus: {
        youtubeApiConfigured: Boolean(process.env.YOUTUBE_API_KEY?.trim()),
        geminiApiConfigured: Boolean(process.env.GEMINI_API_KEY?.trim()),
      },
    });
  });

  router.get('/videos', (req: Request, res: Response) => {
    const q = typeof req.query.q === 'string' ? req.query.q.trim() : '';
    const sort = req.query.sort === 'popular' ? 'popular' : 'latest';
    const category = typeof req.query.category === 'string' ? req.query.category.trim() : 'all';
    const page = Math.max(1, Number(req.query.page) || 1);
    const limit = Math.min(24, Math.max(1, Number(req.query.limit) || 12));
    const offset = (page - 1) * limit;

    const where: string[] = [];
    const params: Array<string | number> = [];

    if (category === 'Short') {
      where.push('is_short = 1');
    } else if (category === 'Livestream') {
      where.push('is_livestream = 1');
    } else if (category === 'Upload') {
      where.push('is_short = 0 AND is_livestream = 0');
    } else if (category === 'videos_only') {
      where.push('is_short = 0');
    }

    if (q) {
      where.push('(lower(title) LIKE ? OR lower(description) LIKE ?)');
      params.push(`%${q.toLowerCase()}%`, `%${q.toLowerCase()}%`);
    }

    const whereClause = where.length > 0 ? `WHERE ${where.join(' AND ')}` : '';
    const orderClause =
      sort === 'popular' ? 'ORDER BY COALESCE(view_count, 0) DESC, published_at DESC' : 'ORDER BY published_at DESC';

    const totalRow = db
      .prepare(`SELECT COUNT(*) as total FROM videos ${whereClause}`)
      .get(...params) as { total: number };
    const rows = db
      .prepare(`SELECT * FROM videos ${whereClause} ${orderClause} LIMIT ? OFFSET ?`)
      .all(...params, limit, offset) as VideoRow[];

    res.json({
      items: rows.map(serializeVideo),
      total: totalRow.total,
      page,
      limit,
      totalPages: Math.max(1, Math.ceil(totalRow.total / limit)),
    });
  });

  router.get('/shorts', (_req: Request, res: Response) => {
    const rows = db
      .prepare('SELECT * FROM videos WHERE is_short = 1 ORDER BY published_at DESC LIMIT 40')
      .all() as VideoRow[];
    res.json({
      items: rows.map(serializeVideo),
      total: rows.length,
    });
  });

  router.get('/live', (_req: Request, res: Response) => {
    const stats = serializeStats();
    const recentLivestreams = (
      db
        .prepare(
          "SELECT * FROM videos WHERE is_livestream = 1 AND live_status != 'live' ORDER BY published_at DESC LIMIT 8"
        )
        .all() as VideoRow[]
    ).map(serializeVideo);
    const latestUploads = (
      db.prepare('SELECT * FROM videos WHERE is_short = 0 ORDER BY published_at DESC LIMIT 6').all() as VideoRow[]
    ).map(serializeVideo);

    res.json({
      isLive: stats.isLive,
      liveVideoId: stats.liveVideoId,
      liveTitle: stats.liveTitle,
      liveThumbnail: stats.liveThumbnail,
      liveStartedAt: stats.liveStartedAt,
      liveViewers: stats.liveViewers,
      upcomingLive: stats.upcomingLive,
      lastLiveSync: stats.lastLiveSync,
      recentLivestreams,
      latestUploads,
    });
  });

  const contactSchema = z.object({
    name: z.string().trim().min(2, 'Name must be at least 2 characters.').max(100),
    email: z.string().trim().email('Please provide a valid email address.').max(160),
    inquiryType: z.enum(['Business', 'Sponsorship', 'Collaboration', 'General']),
    company: z.string().trim().max(120).optional().default(''),
    message: z.string().trim().min(10, 'Message must be at least 10 characters.').max(3000),
    website: z.string().optional().default(''), // honeypot
  });

  router.post('/contact', contactLimiter, (req: Request, res: Response) => {
    const parsed = contactSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid form submission.' });
      return;
    }
    if (parsed.data.website) {
      // Honeypot triggered — silently accept without saving
      res.status(201).json({ success: true });
      return;
    }

    db.prepare(
      'INSERT INTO contact_submissions (name, email, inquiry_type, company, message, is_read, created_at) VALUES (?, ?, ?, ?, ?, 0, ?)'
    ).run(
      parsed.data.name,
      parsed.data.email,
      parsed.data.inquiryType,
      parsed.data.company || '',
      parsed.data.message,
      new Date().toISOString()
    );

    res.status(201).json({ success: true, message: 'Your inquiry has been submitted.' });
  });

  const generateSchema = z.object({
    channelName: z.string().trim().min(2, 'Channel name is required.').max(80),
    youtubeChannelUrl: z
      .string()
      .trim()
      .min(5, 'YouTube channel URL is required.')
      .refine((v) => /youtube\.com|youtu\.be|^@[\w.-]+$|^UC[\w-]{20,}$/i.test(v), {
        message: 'Enter a valid YouTube channel URL or @handle.',
      }),
    discordInviteUrl: z
      .string()
      .trim()
      .min(5, 'Discord invite URL is required.')
      .refine((v) => /^https?:\/\/(discord\.gg|discord\.com\/invite)\//i.test(v), {
        message: 'Enter a valid Discord invite link (https://discord.gg/...).',
      }),
    desiredPort: z.coerce
      .number()
      .int()
      .min(1024, 'Port must be between 1024 and 65535.')
      .max(65535, 'Port must be between 1024 and 65535.'),
  });

  router.post('/setup/generate', setupLimiter, async (req: Request, res: Response) => {
    const parsed = generateSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid setup inputs.' });
      return;
    }

    const { channelName, youtubeChannelUrl, discordInviteUrl, desiredPort } = parsed.data;
    const now = new Date().toISOString();

    // Reset cached channel-specific items cleanly so the newly generated site only contains the new creator's real data
    db.prepare('DELETE FROM videos').run();
    db.prepare(`
      UPDATE site_config
      SET channel_name = ?,
          youtube_channel_url = ?,
          discord_invite_url = ?,
          desired_port = ?,
          channel_id = NULL,
          channel_handle = NULL,
          avatar_url = NULL,
          banner_url = NULL,
          channel_description = '',
          featured_video_id = NULL,
          hero_headline = ?,
          hero_subheadline = ?,
          updated_at = ?
      WHERE id = 1
    `).run(
      channelName,
      youtubeChannelUrl,
      discordInviteUrl,
      desiredPort,
      `${channelName} — Official Creator Hub`,
      `Latest YouTube videos, verified Shorts, and community updates from ${channelName}.`,
      now
    );

    db.prepare(`
      UPDATE channel_stats
      SET subscriber_count = NULL,
          subscriber_display = NULL,
          hidden_subscriber_count = 0,
          subscriber_source = 'pending',
          subscriber_unavailable_reason = 'Synchronizing channel statistics...',
          view_count = NULL,
          video_count = NULL,
          is_live = 0,
          live_video_id = NULL,
          live_title = NULL,
          live_thumbnail = NULL,
          live_started_at = NULL,
          live_viewers = NULL,
          upcoming_live_json = '[]',
          last_error = NULL
      WHERE id = 1
    `).run();

    const syncResult = await runSyncTask('all', true);
    const updatedSite = getSiteConfig();
    const deployment = buildDeploymentSnippets(updatedSite);

    res.json({
      success: true,
      syncResult,
      site: serializeSite(updatedSite),
      stats: serializeStats(),
      deployment,
    });
  });

  // --- Admin Auth & Management Endpoints ---
  router.get('/admin/status', (req: Request, res: Response) => {
    const needsSetup = !hasAnyAdminUser();
    const token = req.cookies?.[SESSION_COOKIE_NAME] as string | undefined;
    const session = getSession(token);
    res.json({
      needsSetup,
      authenticated: Boolean(session),
      username: session?.username || null,
      csrfToken: session?.csrfToken || null,
    });
  });

  const adminCredsSchema = z.object({
    username: z.string().trim().min(3, 'Username must be at least 3 characters.').max(40),
    password: z.string().min(8, 'Password must be at least 8 characters.').max(128),
  });

  router.post('/admin/setup', authLimiter, (req: Request, res: Response) => {
    if (hasAnyAdminUser()) {
      res.status(403).json({ error: 'Admin account already exists. Please log in.' });
      return;
    }
    const parsed = adminCredsSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid credentials.' });
      return;
    }
    const user = createAdminUser(parsed.data.username, parsed.data.password);
    const session = createSession(user.id);

    res.cookie(SESSION_COOKIE_NAME, session.token, {
      httpOnly: true,
      sameSite: 'lax',
      secure: process.env.NODE_ENV === 'production' && req.secure,
      maxAge: 24 * 60 * 60 * 1000,
    });

    res.status(201).json({
      authenticated: true,
      username: user.username,
      csrfToken: session.csrfToken,
    });
  });

  router.post('/admin/login', authLimiter, (req: Request, res: Response) => {
    const parsed = adminCredsSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: 'Invalid username or password format.' });
      return;
    }
    const user = verifyAdminCredentials(parsed.data.username, parsed.data.password);
    if (!user) {
      res.status(401).json({ error: 'Invalid username or password.' });
      return;
    }
    const session = createSession(user.id);

    res.cookie(SESSION_COOKIE_NAME, session.token, {
      httpOnly: true,
      sameSite: 'lax',
      secure: process.env.NODE_ENV === 'production' && req.secure,
      maxAge: 24 * 60 * 60 * 1000,
    });

    res.json({
      authenticated: true,
      username: user.username,
      csrfToken: session.csrfToken,
    });
  });

  router.post('/admin/logout', (req: Request, res: Response) => {
    const token = req.cookies?.[SESSION_COOKIE_NAME] as string | undefined;
    deleteSession(token);
    res.clearCookie(SESSION_COOKIE_NAME);
    res.json({ success: true });
  });

  router.get('/admin/dashboard', requireAdmin, (_req: AuthenticatedRequest, res: Response) => {
    const site = getSiteConfig();
    const stats = serializeStats();
    const contacts = db.prepare('SELECT * FROM contact_submissions ORDER BY id DESC LIMIT 100').all();
    const logs = db.prepare('SELECT * FROM sync_logs ORDER BY id DESC LIMIT 40').all();
    const allVideos = (
      db.prepare('SELECT * FROM videos ORDER BY published_at DESC LIMIT 50').all() as VideoRow[]
    ).map(serializeVideo);

    res.json({
      site: serializeSite(site),
      stats,
      contacts,
      logs,
      videos: allVideos,
      deployment: buildDeploymentSnippets(site),
      runtime: {
        activePort: Number(process.env.PORT) || 3000,
        nodeVersion: process.version,
        youtubeApiConfigured: Boolean(process.env.YOUTUBE_API_KEY?.trim()),
        geminiApiConfigured: Boolean(process.env.GEMINI_API_KEY?.trim()),
        subscriberRefreshIntervalMs: Number(process.env.SUBSCRIBER_REFRESH_INTERVAL) || 300000,
        videoRefreshIntervalMs: Number(process.env.VIDEO_REFRESH_INTERVAL) || 600000,
        liveRefreshIntervalMs: Number(process.env.LIVE_REFRESH_INTERVAL) || 120000,
      },
    });
  });

  router.post('/admin/refresh', requireAdmin, async (req: AuthenticatedRequest, res: Response) => {
    const scope =
      req.body?.scope === 'subscribers' ||
      req.body?.scope === 'videos' ||
      req.body?.scope === 'live'
        ? req.body.scope
        : 'all';
    const rebrand = Boolean(req.body?.rebrand);

    const result = await runSyncTask(scope, rebrand);
    if (rebrand && !result.success) {
      await generateAndApplyChannelBranding();
    }

    res.json({
      success: result.success,
      mode: result.mode,
      error: result.error || null,
      site: serializeSite(getSiteConfig()),
      stats: serializeStats(),
    });
  });

  const adminSettingsSchema = z.object({
    channelName: z.string().trim().min(2).max(80),
    youtubeChannelUrl: z.string().trim().min(5).max(300),
    discordInviteUrl: z.string().trim().min(5).max(300),
    desiredPort: z.coerce.number().int().min(1024).max(65535),
    niche: z.string().trim().min(2).max(80),
    categories: z.array(z.string().trim().min(1).max(40)).max(6),
    heroHeadline: z.string().trim().min(2).max(140),
    heroSubheadline: z.string().trim().min(2).max(300),
    aboutText: z.string().trim().min(2).max(2000),
    communityPitch: z.string().trim().min(2).max(600),
    themeMode: z.enum(['dark', 'light']),
    primaryColor: z.string().regex(/^#[0-9a-fA-F]{6}$/),
    secondaryColor: z.string().regex(/^#[0-9a-fA-F]{6}$/),
    accentColor: z.string().regex(/^#[0-9a-fA-F]{6}$/),
    fontDisplay: z.enum(['Outfit', 'Barlow Condensed', 'Bricolage Grotesque', 'Archivo', 'Playfair Display']),
    fontBody: z.enum(['Plus Jakarta Sans', 'DM Sans', 'Manrope', 'Public Sans', 'Source Serif 4']),
    socialLinks: z.record(z.string(), z.string().max(300)),
  });

  router.put('/admin/settings', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
    const parsed = adminSettingsSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.issues[0]?.message || 'Invalid settings payload.' });
      return;
    }

    const d = parsed.data;
    const now = new Date().toISOString();

    db.prepare(`
      UPDATE site_config
      SET channel_name = ?,
          youtube_channel_url = ?,
          discord_invite_url = ?,
          desired_port = ?,
          niche = ?,
          categories_json = ?,
          hero_headline = ?,
          hero_subheadline = ?,
          about_text = ?,
          community_pitch = ?,
          theme_mode = ?,
          primary_color = ?,
          secondary_color = ?,
          accent_color = ?,
          font_display = ?,
          font_body = ?,
          social_links_json = ?,
          updated_at = ?
      WHERE id = 1
    `).run(
      d.channelName,
      d.youtubeChannelUrl,
      d.discordInviteUrl,
      d.desiredPort,
      d.niche,
      JSON.stringify(d.categories),
      d.heroHeadline,
      d.heroSubheadline,
      d.aboutText,
      d.communityPitch,
      d.themeMode,
      d.primaryColor,
      d.secondaryColor,
      d.accentColor,
      d.fontDisplay,
      d.fontBody,
      JSON.stringify(d.socialLinks),
      now
    );

    const updatedSite = getSiteConfig();
    broadcastSseEvent('channel-updated', {
      type: 'settings',
      updatedAt: now,
      stats: getChannelStats(),
      site: updatedSite,
    });

    res.json({
      success: true,
      site: serializeSite(updatedSite),
      deployment: buildDeploymentSnippets(updatedSite),
    });
  });

  router.post('/admin/featured', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
    const videoId = typeof req.body?.videoId === 'string' && req.body.videoId.trim() ? req.body.videoId.trim() : null;
    db.prepare('UPDATE videos SET is_featured = 0').run();
    if (videoId) {
      db.prepare('UPDATE videos SET is_featured = 1 WHERE id = ?').run(videoId);
    }
    db.prepare('UPDATE site_config SET featured_video_id = ?, updated_at = ? WHERE id = 1').run(
      videoId,
      new Date().toISOString()
    );

    broadcastSseEvent('channel-updated', {
      type: 'featured',
      updatedAt: new Date().toISOString(),
    });

    res.json({ success: true, featuredVideoId: videoId });
  });

  router.patch('/admin/contacts/:id', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) {
      res.status(400).json({ error: 'Invalid submission ID.' });
      return;
    }
    const isRead = req.body?.isRead ? 1 : 0;
    db.prepare('UPDATE contact_submissions SET is_read = ? WHERE id = ?').run(isRead, id);
    res.json({ success: true });
  });

  router.delete('/admin/contacts/:id', requireAdmin, (req: AuthenticatedRequest, res: Response) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) {
      res.status(400).json({ error: 'Invalid submission ID.' });
      return;
    }
    db.prepare('DELETE FROM contact_submissions WHERE id = ?').run(id);
    res.json({ success: true });
  });

  return router;
}

export function registerSeoRoutes(app: express.Express) {
  app.get('/robots.txt', (req: Request, res: Response) => {
    const baseUrl = (process.env.APP_URL || `${req.protocol}://${req.get('host')}`).replace(/\/+$/, '');
    res.type('text/plain').send(
      [
        'User-agent: *',
        'Allow: /',
        'Disallow: /admin',
        'Disallow: /api/',
        `Sitemap: ${baseUrl}/sitemap.xml`,
      ].join('\n')
    );
  });

  app.get('/sitemap.xml', (req: Request, res: Response) => {
    const baseUrl = (process.env.APP_URL || `${req.protocol}://${req.get('host')}`).replace(/\/+$/, '');
    const routes = ['/', '/about', '/videos', '/shorts', '/live', '/community', '/contact', '/setup'];
    const lastMod = new Date().toISOString().split('T')[0];

    const urls = routes
      .map(
        (route) => `  <url>
    <loc>${baseUrl}${route}</loc>
    <lastmod>${lastMod}</lastmod>
    <changefreq>${route === '/' || route === '/videos' || route === '/live' ? 'hourly' : 'weekly'}</changefreq>
    <priority>${route === '/' ? '1.0' : '0.8'}</priority>
  </url>`
      )
      .join('\n');

    res.type('application/xml').send(`<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls}
</urlset>`);
  });
}
