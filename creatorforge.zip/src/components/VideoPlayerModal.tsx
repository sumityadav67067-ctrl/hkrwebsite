import { ExternalLink, X } from 'lucide-react';
import { useEffect } from 'react';
import { formatCompactNumber, formatRelativeDate, type VideoItem } from '../types';

interface VideoPlayerModalProps {
  video: VideoItem | null;
  onClose: () => void;
}

export function VideoPlayerModal({ video, onClose }: VideoPlayerModalProps) {
  useEffect(() => {
    if (!video) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [video, onClose]);

  if (!video) return null;

  const watchUrl = video.isShort
    ? `https://www.youtube.com/shorts/${video.id}`
    : `https://www.youtube.com/watch?v=${video.id}`;
  const views = formatCompactNumber(video.viewCount);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={video.title}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="w-full max-w-4xl rounded-xl border border-white/10 bg-[#0d1017] text-white overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between gap-4 px-5 py-3.5 border-b border-white/10">
          <h2 className="font-display text-base sm:text-lg font-semibold truncate">{video.title}</h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close video player"
            className="w-9 h-9 inline-flex items-center justify-center rounded-lg hover:bg-white/10 text-slate-300"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className={video.isShort ? 'flex justify-center bg-black py-4' : 'aspect-video bg-black'}>
          <iframe
            src={`https://www.youtube.com/embed/${video.id}?autoplay=1&rel=0`}
            title={video.title}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            className={video.isShort ? 'w-full max-w-[360px] aspect-[9/16] rounded-lg' : 'w-full h-full'}
          />
        </div>

        <div className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-t border-white/10">
          <div className="space-y-1 min-w-0">
            <div className="text-xs text-slate-400">
              <span>{formatRelativeDate(video.publishedAt)}</span>
              {views && (
                <>
                  <span className="mx-2" aria-hidden="true">
                    ·
                  </span>
                  <span className="tabular-nums">{views} views</span>
                </>
              )}
              {video.durationFormatted && (
                <>
                  <span className="mx-2" aria-hidden="true">
                    ·
                  </span>
                  <span className="font-mono-tabular">{video.durationFormatted}</span>
                </>
              )}
            </div>
            {video.description && <p className="text-sm text-slate-300 line-clamp-2">{video.description}</p>}
          </div>

          <a
            href={watchUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg text-slate-950 whitespace-nowrap shrink-0"
            style={{ backgroundColor: 'var(--brand-primary)' }}
          >
            <span>Watch on YouTube</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>
    </div>
  );
}
