import { Play, Video as VideoIcon } from 'lucide-react';
import { useState } from 'react';
import { formatCompactNumber, formatRelativeDate, type VideoItem } from '../types';

interface VideoCardProps {
  video: VideoItem;
  onPlay: (video: VideoItem) => void;
}

export function VideoCard({ video, onPlay }: VideoCardProps) {
  const [imgError, setImgError] = useState(false);
  const viewsText = formatCompactNumber(video.viewCount);

  return (
    <article className="group flex flex-col rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] overflow-hidden transition-colors hover:border-slate-300 dark:hover:border-white/20">
      <button
        type="button"
        onClick={() => onPlay(video)}
        className="relative aspect-video w-full overflow-hidden bg-slate-900 text-left focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--brand-primary)]"
        aria-label={`Play ${video.title}`}
      >
        {!imgError && video.thumbnailUrl ? (
          <img
            src={video.thumbnailUrl}
            alt={video.title}
            loading="lazy"
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center gap-2 bg-gradient-to-br from-slate-800 to-slate-950 text-slate-400 p-4">
            <VideoIcon className="w-8 h-8 opacity-60" />
            <span className="text-xs text-center line-clamp-2">{video.title}</span>
          </div>
        )}

        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/15 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />

        <div className="absolute inset-0 flex items-center justify-center">
          <span className="w-12 h-12 rounded-full bg-black/70 border border-white/25 text-white flex items-center justify-center transition-transform duration-150 group-hover:scale-110">
            <Play className="w-5 h-5 fill-current ml-0.5" />
          </span>
        </div>

        {video.durationFormatted && (
          <span className="absolute bottom-2.5 right-2.5 px-2 py-0.5 rounded bg-black/80 text-white font-mono-tabular text-xs font-medium">
            {video.durationFormatted}
          </span>
        )}
      </button>

      <div className="p-4 flex flex-col flex-1 justify-between gap-3">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            <span>{video.category}</span>
            <span aria-hidden="true">·</span>
            <span>{formatRelativeDate(video.publishedAt)}</span>
            {viewsText && (
              <>
                <span aria-hidden="true">·</span>
                <span className="tabular-nums">{viewsText} views</span>
              </>
            )}
          </div>
          <h3 className="font-display text-base font-semibold text-slate-900 dark:text-white leading-snug line-clamp-2">
            <button
              type="button"
              onClick={() => onPlay(video)}
              className="text-left hover:underline focus-visible:outline-none"
            >
              {video.title}
            </button>
          </h3>
        </div>

        <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-white/5 text-xs">
          <button
            type="button"
            onClick={() => onPlay(video)}
            className="font-semibold text-slate-900 dark:text-slate-200 hover:underline"
          >
            Watch here
          </button>
          <a
            href={
              video.isShort
                ? `https://www.youtube.com/shorts/${video.id}`
                : `https://www.youtube.com/watch?v=${video.id}`
            }
            target="_blank"
            rel="noopener noreferrer"
            className="text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
          >
            YouTube →
          </a>
        </div>
      </div>
    </article>
  );
}
