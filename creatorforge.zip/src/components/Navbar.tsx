import { Menu, X } from 'lucide-react';
import { useState } from 'react';
import { useSite } from '../context/SiteContext';

const PRIMARY_NAV_ITEMS = [
  { label: 'Videos', path: '/videos' },
  { label: 'Shorts', path: '/shorts' },
  { label: 'Live', path: '/live' },
  { label: 'Community', path: '/community' },
  { label: 'About', path: '/about' },
];

const MOBILE_EXTRA_ITEMS = [
  { label: 'Home', path: '/' },
  ...PRIMARY_NAV_ITEMS,
  { label: 'Contact', path: '/contact' },
  { label: 'Creator Builder', path: '/setup' },
  { label: 'Admin', path: '/admin' },
];

export function Navbar() {
  const { data, currentPath, navigate } = useSite();
  const [mobileOpen, setMobileOpen] = useState(false);

  const channelName = data?.site.channelName || 'Creator Hub';
  const youtubeUrl = data?.site.youtubeChannelUrl || 'https://www.youtube.com';
  const subscribeHref = youtubeUrl.includes('?') ? `${youtubeUrl}&sub_confirmation=1` : `${youtubeUrl}?sub_confirmation=1`;

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200/80 dark:border-white/10 bg-white/90 dark:bg-[#090b10]/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single-element brand wordmark */}
        <a
          href="/"
          onClick={(e) => {
            e.preventDefault();
            navigate('/');
          }}
          className="font-display text-lg font-bold tracking-tight text-slate-900 dark:text-white whitespace-nowrap shrink-0"
        >
          {channelName}
        </a>

        {/* Zone 2: 5 concise single-line navigation links */}
        <nav aria-label="Primary navigation" className="hidden md:flex items-center gap-7">
          {PRIMARY_NAV_ITEMS.map((item) => {
            const active = currentPath === item.path;
            return (
              <a
                key={item.path}
                href={item.path}
                onClick={(e) => {
                  e.preventDefault();
                  navigate(item.path);
                }}
                className={`text-sm font-medium whitespace-nowrap shrink-0 transition-colors border-b-2 py-1 ${
                  active
                    ? 'text-slate-950 dark:text-white border-[var(--brand-primary)]'
                    : 'text-slate-600 dark:text-slate-400 border-transparent hover:text-slate-950 dark:hover:text-white'
                }`}
              >
                {item.label}
              </a>
            );
          })}
        </nav>

        {/* Zone 3: 1 primary CTA button + mobile menu trigger */}
        <div className="flex items-center gap-3 shrink-0">
          <a
            href={subscribeHref}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:inline-flex items-center justify-center px-4 py-2 text-xs font-semibold rounded-lg text-slate-950 transition-transform duration-150 hover:opacity-95 active:scale-[0.98] whitespace-nowrap shrink-0"
            style={{ backgroundColor: 'var(--brand-primary)' }}
          >
            Subscribe
          </a>

          <button
            type="button"
            aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={mobileOpen}
            onClick={() => setMobileOpen((prev) => !prev)}
            className="md:hidden inline-flex items-center justify-center w-11 h-11 rounded-lg border border-slate-200 dark:border-white/10 text-slate-800 dark:text-slate-200"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="md:hidden border-t border-slate-200 dark:border-white/10 bg-white dark:bg-[#0d1017] px-4 py-4 space-y-1">
          {MOBILE_EXTRA_ITEMS.map((item) => {
            const active = currentPath === item.path;
            return (
              <a
                key={item.path}
                href={item.path}
                onClick={(e) => {
                  e.preventDefault();
                  navigate(item.path);
                  setMobileOpen(false);
                }}
                className={`block px-3 py-2.5 rounded-lg text-sm font-medium ${
                  active
                    ? 'bg-slate-100 dark:bg-white/10 text-slate-950 dark:text-white'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                {item.label}
              </a>
            );
          })}
          <div className="pt-2">
            <a
              href={subscribeHref}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center w-full px-4 py-2.5 text-sm font-semibold rounded-lg text-slate-950"
              style={{ backgroundColor: 'var(--brand-primary)' }}
            >
              Subscribe on YouTube
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
