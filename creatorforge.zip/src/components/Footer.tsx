import { useSite } from '../context/SiteContext';

export function Footer() {
  const { data, navigate } = useSite();
  const site = data?.site;
  const channelName = site?.channelName || 'Creator Hub';
  const year = new Date().getFullYear();

  const links = [
    { label: 'Home', path: '/' },
    { label: 'Videos', path: '/videos' },
    { label: 'Shorts', path: '/shorts' },
    { label: 'Live', path: '/live' },
    { label: 'About', path: '/about' },
    { label: 'Community', path: '/community' },
    { label: 'Contact', path: '/contact' },
    { label: 'Creator Builder', path: '/setup' },
    { label: 'Admin', path: '/admin' },
  ];

  const socialEntries = Object.entries(site?.socialLinks || {}).filter(([, val]) => Boolean(val));

  return (
    <footer className="border-t border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#07090d] mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          <div className="space-y-3">
            <div className="font-display text-lg font-bold text-slate-900 dark:text-white">{channelName}</div>
            <p className="text-sm text-slate-600 dark:text-slate-400 max-w-sm leading-relaxed">
              {site?.niche || 'Digital Content Creator'} — Official YouTube hub, Shorts showcase, live stream status,
              and Discord community portal.
            </p>
          </div>

          <div className="space-y-3">
            <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">Navigation</div>
            <div className="grid grid-cols-2 gap-x-6 gap-y-2 text-sm">
              {links.map((item) => (
                <a
                  key={item.path}
                  href={item.path}
                  onClick={(e) => {
                    e.preventDefault();
                    navigate(item.path);
                  }}
                  className="text-slate-600 dark:text-slate-400 hover:text-slate-950 dark:hover:text-white transition-colors"
                >
                  {item.label}
                </a>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">Connect</div>
            <div className="flex flex-col gap-2 text-sm">
              {site?.youtubeChannelUrl && (
                <a
                  href={site.youtubeChannelUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-slate-600 dark:text-slate-400 hover:text-slate-950 dark:hover:text-white transition-colors"
                >
                  YouTube Channel
                </a>
              )}
              {site?.discordInviteUrl && (
                <a
                  href={site.discordInviteUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-slate-600 dark:text-slate-400 hover:text-slate-950 dark:hover:text-white transition-colors"
                >
                  Discord Community
                </a>
              )}
              {socialEntries.map(([platform, url]) => (
                <a
                  key={platform}
                  href={url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="capitalize text-slate-600 dark:text-slate-400 hover:text-slate-950 dark:hover:text-white transition-colors"
                >
                  {platform}
                </a>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-slate-200/80 dark:border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-slate-500 dark:text-slate-500">
          <p>
            © {year} {channelName}. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            <a href="/sitemap.xml" className="hover:text-slate-800 dark:hover:text-slate-300">
              Sitemap
            </a>
            <a href="/robots.txt" className="hover:text-slate-800 dark:hover:text-slate-300">
              Robots
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
