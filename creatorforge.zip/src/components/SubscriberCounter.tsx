import { useEffect, useRef, useState } from 'react';
import { ExternalLink } from 'lucide-react';
import { formatRelativeDate, type ChannelStats, type SiteConfig } from '../types';

const FALLBACK_AVATAR = '/src/assets/images/creator_avatar_emblem_1794531453664.jpg';

interface SubscriberCounterProps {
  site: SiteConfig;
  stats: ChannelStats;
}

export function SubscriberCounter({ site, stats }: SubscriberCounterProps) {
  const [displayedCount, setDisplayedCount] = useState<number | null>(stats.subscriberCount);
  const [avatarFailed, setAvatarFailed] = useState(false);
  const prevRef = useRef<number | null>(stats.subscriberCount);

  useEffect(() => {
    const target = stats.subscriberCount;
    if (target === null) {
      setDisplayedCount(null);
      prevRef.current = null;
      return;
    }

    const start = prevRef.current ?? target;
    if (start === target) {
      setDisplayedCount(target);
      return;
    }

    const duration = 700;
    const startTime = performance.now();
    let rafId = 0;

    const tick = (now: number) => {
      const progress = Math.min(1, (now - startTime) / duration);
      const eased = 1 - Math.pow(1 - progress, 3);
      const current = Math.round(start + (target - start) * eased);
      setDisplayedCount(current);
      if (progress < 1) {
        rafId = requestAnimationFrame(tick);
      } else {
        prevRef.current = target;
      }
    };

    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }, [stats.subscriberCount]);

  useEffect(() => {
    setAvatarFailed(false);
  }, [site.avatarUrl]);

  const subscribeHref = site.youtubeChannelUrl.includes('?')
    ? `${site.youtubeChannelUrl}&sub_confirmation=1`
    : `${site.youtubeChannelUrl}?sub_confirmation=1`;

  const sourceLabel =
    stats.subscriberSource === 'youtube-api'
      ? 'Official YouTube API (Cached)'
      : stats.subscriberSource === 'public-feed'
        ? 'Public Channel Estimate'
        : stats.subscriberSource === 'hidden'
          ? 'Hidden by Creator'
          : 'Count Unavailable';

  return (
    <section
      aria-label="Live Subscriber Counter"
      className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] p-6 sm:p-8"
    >
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-8">
        <div className="flex items-center gap-5 min-w-0">
          <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-xl overflow-hidden border border-slate-200 dark:border-white/10 bg-slate-900 shrink-0">
            <img
              src={!avatarFailed && site.avatarUrl ? site.avatarUrl : FALLBACK_AVATAR}
              alt={`${site.channelName} profile avatar`}
              referrerPolicy="no-referrer"
              onError={() => setAvatarFailed(true)}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="min-w-0 space-y-1">
            <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
              {sourceLabel}
              <span className="mx-2" aria-hidden="true">
                ·
              </span>
              <span>
                {stats.lastSubscriberSync ? `Updated ${formatRelativeDate(stats.lastSubscriberSync)}` : 'Sync pending'}
              </span>
            </div>
            <h2 className="font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-white truncate">
              {site.channelName}
            </h2>
            {site.channelHandle && (
              <div className="text-sm text-slate-500 dark:text-slate-400 truncate">{site.channelHandle}</div>
            )}
          </div>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center gap-6 sm:gap-10">
          <div className="space-y-1">
            <div className="text-xs font-semibold tracking-wider text-slate-500 dark:text-slate-400">Subscribers</div>
            {displayedCount !== null ? (
              <div className="font-mono-tabular text-4xl sm:text-5xl font-bold tracking-tight text-slate-950 dark:text-white">
                {displayedCount.toLocaleString('en-US')}
              </div>
            ) : stats.subscriberDisplay ? (
              <div className="font-mono-tabular text-4xl sm:text-5xl font-bold tracking-tight text-slate-950 dark:text-white">
                {stats.subscriberDisplay}
              </div>
            ) : (
              <div className="space-y-1">
                <div className="font-display text-2xl font-bold text-slate-700 dark:text-slate-300">Unavailable</div>
                {stats.subscriberUnavailableReason && (
                  <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xs">
                    {stats.subscriberUnavailableReason}
                  </p>
                )}
              </div>
            )}
          </div>

          <a
            href={subscribeHref}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 px-6 py-3 text-sm font-semibold rounded-lg text-slate-950 transition-transform duration-150 hover:opacity-95 active:scale-[0.98] whitespace-nowrap shrink-0"
            style={{ backgroundColor: 'var(--brand-primary)' }}
          >
            <span>Subscribe</span>
            <ExternalLink className="w-4 h-4" />
          </a>
        </div>
      </div>
    </section>
  );
}
