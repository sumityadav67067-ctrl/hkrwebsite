import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import type { SitePayload } from '../types';

interface SiteContextValue {
  data: SitePayload | null;
  loading: boolean;
  error: string | null;
  refreshSite: () => Promise<void>;
  currentPath: string;
  navigate: (path: string) => void;
}

const SiteContext = createContext<SiteContextValue | undefined>(undefined);

const FONT_CSS_MAP: Record<string, string> = {
  Outfit: '"Outfit", system-ui, sans-serif',
  'Barlow Condensed': '"Barlow Condensed", system-ui, sans-serif',
  'Bricolage Grotesque': '"Bricolage Grotesque", system-ui, sans-serif',
  Archivo: '"Archivo", system-ui, sans-serif',
  'Playfair Display': '"Playfair Display", Georgia, serif',
  'Plus Jakarta Sans': '"Plus Jakarta Sans", system-ui, sans-serif',
  'DM Sans': '"DM Sans", system-ui, sans-serif',
  Manrope: '"Manrope", system-ui, sans-serif',
  'Public Sans': '"Public Sans", system-ui, sans-serif',
  'Source Serif 4': '"Source Serif 4", Georgia, serif',
};

function applyThemeAndSeo(payload: SitePayload) {
  const { site } = payload;
  const root = document.documentElement;
  if (site.themeMode === 'dark') {
    root.classList.add('dark');
  } else {
    root.classList.remove('dark');
  }

  root.style.setProperty('--brand-primary', site.primaryColor || '#f59e0b');
  root.style.setProperty('--brand-secondary', site.secondaryColor || '#1e293b');
  root.style.setProperty('--brand-accent', site.accentColor || '#fbbf24');
  root.style.setProperty('--font-display', FONT_CSS_MAP[site.fontDisplay] || FONT_CSS_MAP.Outfit);
  root.style.setProperty('--font-body', FONT_CSS_MAP[site.fontBody] || FONT_CSS_MAP['Plus Jakarta Sans']);

  document.title = `${site.channelName} — ${site.niche} Creator Hub`;
  const metaDesc = document.querySelector('meta[name="description"]');
  if (metaDesc) {
    metaDesc.setAttribute('content', site.heroSubheadline || site.aboutText.slice(0, 155));
  }
  const ogTitle = document.querySelector('meta[property="og:title"]');
  if (ogTitle) {
    ogTitle.setAttribute('content', `${site.channelName} — Official Creator Website`);
  }

  // Inject or update Schema.org JSON-LD
  let ldScript = document.getElementById('creator-jsonld') as HTMLScriptElement | null;
  if (!ldScript) {
    ldScript = document.createElement('script');
    ldScript.id = 'creator-jsonld';
    ldScript.type = 'application/ld+json';
    document.head.appendChild(ldScript);
  }
  const sameAs = [site.youtubeChannelUrl, site.discordInviteUrl, ...Object.values(site.socialLinks || {})].filter(
    Boolean
  );
  ldScript.textContent = JSON.stringify({
    '@context': 'https://schema.org',
    '@type': 'Person',
    name: site.channelName,
    description: site.aboutText,
    url: window.location.origin,
    sameAs,
  });
}

export function SiteProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<SitePayload | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentPath, setCurrentPath] = useState<string>(() => window.location.pathname || '/');

  const navigate = useCallback((path: string) => {
    const clean = path.startsWith('/') ? path : `/${path}`;
    if (window.location.pathname !== clean) {
      window.history.pushState({}, '', clean);
    }
    setCurrentPath(clean);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  useEffect(() => {
    const onPopState = () => {
      setCurrentPath(window.location.pathname || '/');
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  const refreshSite = useCallback(async () => {
    try {
      const res = await fetch('/api/site');
      if (!res.ok) {
        throw new Error(`Failed to load channel data (${res.status})`);
      }
      const payload = (await res.json()) as SitePayload;
      setData(payload);
      setError(null);
      applyThemeAndSeo(payload);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load website configuration.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshSite();
  }, [refreshSite]);

  useEffect(() => {
    const eventSource = new EventSource('/api/events');
    const handleUpdate = () => {
      refreshSite();
    };
    eventSource.addEventListener('channel-updated', handleUpdate);
    return () => {
      eventSource.removeEventListener('channel-updated', handleUpdate);
      eventSource.close();
    };
  }, [refreshSite]);

  return (
    <SiteContext.Provider value={{ data, loading, error, refreshSite, currentPath, navigate }}>
      {children}
    </SiteContext.Provider>
  );
}

export function useSite() {
  const ctx = useContext(SiteContext);
  if (!ctx) throw new Error('useSite must be used inside SiteProvider');
  return ctx;
}
