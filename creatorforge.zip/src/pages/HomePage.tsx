import { ArrowRight, ExternalLink, Play, Radio, Sparkles } from 'lucide-react';
import { useState } from 'react';
import { SubscriberCounter } from '../components/SubscriberCounter';
import { VideoCard } from '../components/VideoCard';
import { VideoPlayerModal } from '../components/VideoPlayerModal';
import { useSite } from '../context/SiteContext';
import { formatCompactNumber, formatRelativeDate, type VideoItem } from '../types';

const FALLBACK_HERO = '/src/assets/images/hero_creator_studio_1794531453090.jpg';
const FALLBACK_COMMUNITY = '/src/assets/images/community_discord_lounge_1794531452743.jpg';

export function HomePage() {
  const { data, loading, navigate } = useSite();
  const [activeVideo, setActiveVideo] = useState<VideoItem | null>(null);
  const [heroImgFailed, setHeroImgFailed] = useState(false);

  if (loading || !data) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-16 space-y-10">
        <div className="h-72 rounded-xl bg-slate-200 dark:bg-white/5 animate-pulse" />
        <div className="h-32 rounded-xl bg-slate-200 dark:bg-white/5 animate-pulse" />
      </div>
    );
  }

  const { site, stats, featuredVideo, latestVideos, popularVideos, latestShorts } = data;
  const subscribeHref = site.youtubeChannelUrl.includes('?')
    ? `${site.youtubeChannelUrl}&sub_confirmation=1`
    : `${site.youtubeChannelUrl}?sub_confirmation=1`;

  const heroImage =
    !heroImgFailed && (stats.isLive && stats.liveThumbnail ? stats.liveThumbnail : featuredVideo?.thumbnailUrl || site.bannerUrl)
      ? stats.isLive && stats.liveThumbnail
        ? stats.liveThumbnail
        : featuredVideo?.thumbnailUrl || site.bannerUrl || FALLBACK_HERO
      : FALLBACK_HERO;

  return (
    <div className="space-y-20 pb-8">
      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 pt-10 sm:pt-14">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-stretch">
          <div className="lg:col-span-6 flex flex-col justify-between space-y-8 py-2">
            <div className="space-y-5">
              <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-slate-600 dark:text-slate-400">
                <span>{site.niche}</span>
                {site.channelHandle && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span>{site.channelHandle}</span>
                  </>
                )}
                <span aria-hidden="true">·</span>
                <span>{stats.isLive ? 'Streaming live now' : 'Channel online'}</span>
              </div>

              <h1
                className="font-display font-bold tracking-tight text-slate-950 dark:text-white headline-balance leading-[1.08]"
                style={{ fontSize: 'clamp(2.25rem, 4vw, 3.65rem)' }}
              >
                {site.heroHeadline}
              </h1>

              <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed max-w-xl">
                {site.heroSubheadline}
              </p>
            </div>

            <div className="space-y-4">
              <div className="flex flex-wrap items-center gap-3">
                {stats.isLive && stats.liveVideoId ? (
                  <a
                    href="/live"
                    onClick={(e) => {
                      e.preventDefault();
                      navigate('/live');
                    }}
                    className="inline-flex items-center gap-2 px-6 py-3 rounded-lg text-sm font-semibold bg-red-600 text-white hover:bg-red-500 transition-colors whitespace-nowrap shrink-0"
                  >
                    <Radio className="w-4 h-4" />
                    <span>Watch Live Stream</span>
                  </a>
                ) : (
                  <a
                    href={subscribeHref}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-6 py-3 rounded-lg text-sm font-semibold text-slate-950 transition-transform duration-150 hover:opacity-95 active:scale-[0.98] whitespace-nowrap shrink-0"
                    style={{ backgroundColor: 'var(--brand-primary)' }}
                  >
                    <span>Subscribe on YouTube</span>
                    <ExternalLink className="w-4 h-4" />
                  </a>
                )}

                <a
                  href={site.discordInviteUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-5 py-3 rounded-lg text-sm font-semibold border border-slate-300 dark:border-white/15 text-slate-900 dark:text-white hover:bg-slate-100 dark:hover:bg-white/5 transition-colors whitespace-nowrap shrink-0"
                >
                  <span>Join Discord</span>
                </a>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => navigate('/setup')}
                  className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Generate website for another YouTube creator →</span>
                </button>
              </div>
            </div>
          </div>

          {/* Dominant Focal Carrier */}
          <div className="lg:col-span-6">
            <div className="relative h-full min-h-[280px] sm:min-h-[360px] rounded-xl overflow-hidden border border-slate-200 dark:border-white/10 bg-slate-900">
              <img
                src={heroImage}
                alt={stats.isLive && stats.liveTitle ? stats.liveTitle : featuredVideo?.title || site.channelName}
                referrerPolicy="no-referrer"
                onError={() => setHeroImgFailed(true)}
                className="w-full h-full lg:h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent" />

              {stats.isLive && stats.liveVideoId ? (
                <div className="absolute inset-x-0 bottom-0 p-6 space-y-2 text-white">
                  <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded bg-red-600 text-white text-xs font-bold tracking-wide">
                    LIVE
                    {stats.liveViewers !== null && (
                      <span className="font-mono-tabular font-normal">
                        · {stats.liveViewers.toLocaleString('en-US')} watching
                      </span>
                    )}
                  </div>
                  <h2 className="font-display text-xl sm:text-2xl font-bold leading-snug line-clamp-2">
                    {stats.liveTitle || `${site.channelName} is Live`}
                  </h2>
                  <button
                    type="button"
                    onClick={() => navigate('/live')}
                    className="inline-flex items-center gap-2 text-sm font-semibold text-amber-300 hover:text-amber-200"
                  >
                    <Play className="w-4 h-4 fill-current" />
                    <span>Open live stream page</span>
                  </button>
                </div>
              ) : featuredVideo ? (
                <div className="absolute inset-x-0 bottom-0 p-6 space-y-2 text-white">
                  <div className="text-xs text-slate-300">
                    Featured upload · {formatRelativeDate(featuredVideo.publishedAt)}
                  </div>
                  <h2 className="font-display text-xl sm:text-2xl font-bold leading-snug line-clamp-2">
                    {featuredVideo.title}
                  </h2>
                  <button
                    type="button"
                    onClick={() => setActiveVideo(featuredVideo)}
                    className="inline-flex items-center gap-2 text-sm font-semibold hover:underline"
                    style={{ color: 'var(--brand-accent)' }}
                  >
                    <Play className="w-4 h-4 fill-current" />
                    <span>Play featured video</span>
                  </button>
                </div>
              ) : (
                <div className="absolute inset-x-0 bottom-0 p-6 text-white">
                  <div className="text-xs text-slate-300">{site.niche}</div>
                  <div className="font-display text-xl font-bold">{site.channelName}</div>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Live Subscriber Counter */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <SubscriberCounter site={site} stats={stats} />
      </div>

      {/* Live Stream Status Bar */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            {stats.isLive ? (
              <span className="px-2.5 py-1 rounded bg-red-600 text-white text-xs font-bold tracking-wider">LIVE</span>
            ) : (
              <span className="px-2.5 py-1 rounded border border-slate-300 dark:border-white/15 text-slate-600 dark:text-slate-300 text-xs font-semibold">
                OFFLINE
              </span>
            )}
            <div className="text-sm text-slate-700 dark:text-slate-300">
              {stats.isLive ? (
                <span className="font-medium">{stats.liveTitle || 'Live broadcast in progress'}</span>
              ) : (
                <span>
                  Currently offline
                  {stats.lastLiveSync ? ` · Checked ${formatRelativeDate(stats.lastLiveSync)}` : ''}
                </span>
              )}
            </div>
          </div>
          <a
            href="/live"
            onClick={(e) => {
              e.preventDefault();
              navigate('/live');
            }}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-900 dark:text-white hover:underline whitespace-nowrap shrink-0"
          >
            <span>{stats.isLive ? 'Watch live stream' : 'View stream archive'}</span>
            <ArrowRight className="w-4 h-4" />
          </a>
        </div>
      </section>

      {/* Latest Videos */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 space-y-6">
        <div className="flex items-end justify-between gap-4">
          <div className="space-y-1">
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-slate-950 dark:text-white">
              Latest Videos
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              Automatically synchronized from {site.channelName} on YouTube.
            </p>
          </div>
          <a
            href="/videos"
            onClick={(e) => {
              e.preventDefault();
              navigate('/videos');
            }}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-900 dark:text-white hover:underline whitespace-nowrap shrink-0"
          >
            <span>All videos</span>
            <ArrowRight className="w-4 h-4" />
          </a>
        </div>

        {latestVideos.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {latestVideos.slice(0, 6).map((video) => (
              <VideoCard key={video.id} video={video} onPlay={setActiveVideo} />
            ))}
          </div>
        ) : (
          <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] p-10 text-center space-y-2">
            <p className="text-sm text-slate-600 dark:text-slate-400">
              No long-form uploads retrieved yet. Channel synchronization runs automatically in the background.
            </p>
          </div>
        )}
      </section>

      {/* Verified Shorts Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 space-y-6">
        <div className="flex items-end justify-between gap-4">
          <div className="space-y-1">
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-slate-950 dark:text-white">
              Latest Shorts
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              Verified vertical YouTube Shorts from the channel.
            </p>
          </div>
          <a
            href="/shorts"
            onClick={(e) => {
              e.preventDefault();
              navigate('/shorts');
            }}
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-slate-900 dark:text-white hover:underline whitespace-nowrap shrink-0"
          >
            <span>Shorts gallery</span>
            <ArrowRight className="w-4 h-4" />
          </a>
        </div>

        {latestShorts.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-5">
            {latestShorts.slice(0, 4).map((short) => (
              <button
                key={short.id}
                type="button"
                onClick={() => setActiveVideo(short)}
                className="group relative aspect-[9/16] rounded-xl overflow-hidden border border-slate-200 dark:border-white/10 bg-slate-900 text-left"
              >
                <img
                  src={short.thumbnailUrl}
                  alt={short.title}
                  loading="lazy"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-4 space-y-1 text-white">
                  <div className="text-xs text-slate-300">
                    {formatRelativeDate(short.publishedAt)}
                    {short.viewCount !== null && ` · ${formatCompactNumber(short.viewCount)} views`}
                  </div>
                  <div className="font-display text-sm font-semibold line-clamp-2">{short.title}</div>
                </div>
              </button>
            ))}
          </div>
        ) : (
          <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] p-8 text-sm text-slate-600 dark:text-slate-400">
            No verified YouTube Shorts have been detected for this channel yet. Only confirmed Shorts appear in this
            gallery.
          </div>
        )}
      </section>

      {/* Popular Uploads */}
      {popularVideos.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 space-y-6">
          <div className="space-y-1">
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-slate-950 dark:text-white">
              Popular Uploads
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-400">Most-watched videos across recent releases.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {popularVideos.slice(0, 3).map((video) => (
              <VideoCard key={`pop-${video.id}`} video={video} onPlay={setActiveVideo} />
            ))}
          </div>
        </section>
      )}

      {/* Community Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] overflow-hidden">
          <div className="lg:col-span-7 p-8 sm:p-10 flex flex-col justify-between space-y-6">
            <div className="space-y-3">
              <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">Official Community</div>
              <h2 className="font-display text-2xl sm:text-3xl font-bold text-slate-950 dark:text-white headline-balance">
                Join the {site.channelName} Discord Server
              </h2>
              <p className="text-base text-slate-600 dark:text-slate-300 leading-relaxed">{site.communityPitch}</p>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <a
                href={site.discordInviteUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-lg text-sm font-semibold text-slate-950 whitespace-nowrap shrink-0"
                style={{ backgroundColor: 'var(--brand-primary)' }}
              >
                <span>Join Discord Server</span>
                <ExternalLink className="w-4 h-4" />
              </a>
              <button
                type="button"
                onClick={() => navigate('/community')}
                className="px-5 py-3 rounded-lg text-sm font-semibold border border-slate-300 dark:border-white/15 text-slate-900 dark:text-white hover:bg-slate-100 dark:hover:bg-white/5 transition-colors whitespace-nowrap shrink-0"
              >
                Community Details
              </button>
            </div>
          </div>

          <div className="lg:col-span-5 min-h-[240px] bg-slate-900">
            <img
              src={FALLBACK_COMMUNITY}
              alt="Creator studio community lounge"
              className="w-full h-full lg:h-full object-cover"
            />
          </div>
        </div>
      </section>

      <VideoPlayerModal video={activeVideo} onClose={() => setActiveVideo(null)} />
    </div>
  );
}
