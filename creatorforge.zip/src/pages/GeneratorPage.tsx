import { Check, Copy, Loader2, Sparkles } from 'lucide-react';
import React, { useState } from 'react';
import { useSite } from '../context/SiteContext';

export function GeneratorPage() {
  const { data, refreshSite, navigate } = useSite();
  const [channelName, setChannelName] = useState(data?.site.channelName || 'HkR PlayZ');
  const [youtubeChannelUrl, setYoutubeChannelUrl] = useState(
    data?.site.youtubeChannelUrl || 'https://www.youtube.com/@hkrplayz'
  );
  const [discordInviteUrl, setDiscordInviteUrl] = useState(
    data?.site.discordInviteUrl || 'https://discord.gg/WP5g3uehWd'
  );
  const [desiredPort, setDesiredPort] = useState(String(data?.site.desiredPort || 25595));

  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<{
    envFile: string;
    pm2Config: string;
    port: number;
    niche: string;
    mode: string;
  } | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setGenerating(true);
    try {
      const res = await fetch('/api/setup/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          channelName,
          youtubeChannelUrl,
          discordInviteUrl,
          desiredPort: Number(desiredPort),
        }),
      });
      const json = await res.json();
      if (!res.ok) {
        throw new Error(json.error || 'Failed to generate website.');
      }
      await refreshSite();
      setResult({
        envFile: json.deployment.envFile,
        pm2Config: json.deployment.pm2Config,
        port: json.deployment.port,
        niche: json.site.niche,
        mode: json.syncResult?.mode || 'public-feed',
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Generation error.');
    } finally {
      setGenerating(false);
    }
  };

  const copyText = (key: string, text: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 1800);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12 sm:py-16 space-y-10">
      <div className="space-y-2">
        <div className="text-xs font-medium text-slate-500 dark:text-slate-400">Universal Creator Builder</div>
        <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-950 dark:text-white headline-balance">
          Build Website From 4 Creator Inputs
        </h1>
        <p className="text-base text-slate-600 dark:text-slate-400 max-w-2xl">
          Enter any YouTube creator&apos;s name, channel URL, Discord link, and desired Node.js port. The backend
          analyzes the channel, syncs latest uploads and verified Shorts, detects live streams, and generates bespoke
          branding automatically.
        </p>
      </div>

      <form
        onSubmit={handleGenerate}
        className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] p-6 sm:p-8 space-y-5"
      >
        {error && (
          <div role="alert" className="p-3.5 rounded-lg border border-red-500/30 bg-red-500/10 text-sm text-red-500">
            {error}
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <label className="block space-y-1.5 text-sm">
            <span className="font-medium text-slate-700 dark:text-slate-300">1. Channel Name *</span>
            <input
              type="text"
              required
              value={channelName}
              onChange={(e) => setChannelName(e.target.value)}
              placeholder="HkR PlayZ"
              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#090b10] text-slate-900 dark:text-white focus:outline-none focus:border-[var(--brand-primary)]"
            />
          </label>

          <label className="block space-y-1.5 text-sm">
            <span className="font-medium text-slate-700 dark:text-slate-300">4. Desired Website Port *</span>
            <input
              type="number"
              required
              min={1024}
              max={65535}
              value={desiredPort}
              onChange={(e) => setDesiredPort(e.target.value)}
              placeholder="25595"
              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#090b10] font-mono-tabular text-slate-900 dark:text-white focus:outline-none focus:border-[var(--brand-primary)]"
            />
          </label>
        </div>

        <label className="block space-y-1.5 text-sm">
          <span className="font-medium text-slate-700 dark:text-slate-300">2. YouTube Channel Link *</span>
          <input
            type="text"
            required
            value={youtubeChannelUrl}
            onChange={(e) => setYoutubeChannelUrl(e.target.value)}
            placeholder="https://www.youtube.com/@hkrplayz"
            className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#090b10] text-slate-900 dark:text-white focus:outline-none focus:border-[var(--brand-primary)]"
          />
        </label>

        <label className="block space-y-1.5 text-sm">
          <span className="font-medium text-slate-700 dark:text-slate-300">3. Discord Invite Link *</span>
          <input
            type="url"
            required
            value={discordInviteUrl}
            onChange={(e) => setDiscordInviteUrl(e.target.value)}
            placeholder="https://discord.gg/WP5g3uehWd"
            className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#090b10] text-slate-900 dark:text-white focus:outline-none focus:border-[var(--brand-primary)]"
          />
        </label>

        <div className="flex flex-wrap items-center gap-4 pt-2">
          <button
            type="submit"
            disabled={generating}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-lg text-sm font-semibold text-slate-950 disabled:opacity-50"
            style={{ backgroundColor: 'var(--brand-primary)' }}
          >
            {generating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            <span>{generating ? 'Analyzing Channel & Generating...' : 'Generate Creator Website'}</span>
          </button>

          {result && (
            <button
              type="button"
              onClick={() => navigate('/')}
              className="px-5 py-3 rounded-lg text-sm font-semibold border border-slate-300 dark:border-white/15 text-slate-900 dark:text-white"
            >
              View Live Website →
            </button>
          )}
        </div>
      </form>

      {result && (
        <section className="space-y-6">
          <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-6 space-y-2">
            <div className="font-display text-lg font-bold text-emerald-600 dark:text-emerald-400">
              Website Generated &amp; Synchronized
            </div>
            <p className="text-sm text-slate-700 dark:text-slate-300">
              Detected niche: <strong>{result.niche}</strong> · Sync mode: <strong>{result.mode}</strong> · VPS target
              port: <strong className="font-mono-tabular">{result.port}</strong>
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] overflow-hidden">
              <div className="px-4 py-3 border-b border-slate-200 dark:border-white/10 flex items-center justify-between">
                <span className="font-mono-tabular text-xs font-semibold">.env (Port {result.port})</span>
                <button
                  type="button"
                  onClick={() => copyText('env', result.envFile)}
                  className="inline-flex items-center gap-1 text-xs font-medium text-slate-500 hover:text-slate-900 dark:hover:text-white"
                >
                  {copiedKey === 'env' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'env' ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
              <pre className="p-4 text-xs font-mono-tabular overflow-x-auto text-slate-700 dark:text-slate-300">
                {result.envFile}
              </pre>
            </div>

            <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] overflow-hidden">
              <div className="px-4 py-3 border-b border-slate-200 dark:border-white/10 flex items-center justify-between">
                <span className="font-mono-tabular text-xs font-semibold">ecosystem.config.cjs (PM2)</span>
                <button
                  type="button"
                  onClick={() => copyText('pm2', result.pm2Config)}
                  className="inline-flex items-center gap-1 text-xs font-medium text-slate-500 hover:text-slate-900 dark:hover:text-white"
                >
                  {copiedKey === 'pm2' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'pm2' ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
              <pre className="p-4 text-xs font-mono-tabular overflow-x-auto text-slate-700 dark:text-slate-300">
                {result.pm2Config}
              </pre>
            </div>
          </div>
        </section>
      )}
    </div>
  );
}
