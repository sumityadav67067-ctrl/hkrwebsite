import { ExternalLink } from 'lucide-react';
import { useSite } from '../context/SiteContext';
import { formatCompactNumber } from '../types';

const FALLBACK_AVATAR = '/src/assets/images/creator_avatar_emblem_1794531453664.jpg';

export function AboutPage() {
  const { data, navigate } = useSite();
  if (!data) return null;

  const { site, stats } = data;
  const totalViews = formatCompactNumber(stats.viewCount);
  const totalVideos = formatCompactNumber(stats.videoCount);
  const subs = stats.subscriberCount !== null ? formatCompactNumber(stats.subscriberCount) : stats.subscriberDisplay;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-12 sm:py-16 space-y-12">
      <div className="flex flex-col sm:flex-row sm:items-center gap-6">
        <div className="w-24 h-24 rounded-xl overflow-hidden border border-slate-200 dark:border-white/10 bg-slate-900 shrink-0">
          <img
            src={site.avatarUrl || FALLBACK_AVATAR}
            alt={site.channelName}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="space-y-2">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
            {site.niche}
            {site.channelHandle && ` · ${site.channelHandle}`}
          </div>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-950 dark:text-white">
            About {site.channelName}
          </h1>
        </div>
      </div>

      {/* Verified Channel Overview */}
      <section className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] p-6 sm:p-8 space-y-5">
        <h2 className="font-display text-xl font-bold text-slate-950 dark:text-white">Creator Overview</h2>
        <p className="text-base text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line">
          {site.aboutText}
        </p>
        {site.channelDescription && site.channelDescription !== site.aboutText && (
          <div className="pt-4 border-t border-slate-200 dark:border-white/10 space-y-2">
            <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">Official YouTube Description</div>
            <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed whitespace-pre-line">
              {site.channelDescription}
            </p>
          </div>
        )}
      </section>

      {/* Channel Metrics (only verified metrics displayed) */}
      <section className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] p-6 space-y-1">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">Subscribers</div>
          <div className="font-mono-tabular text-2xl font-bold text-slate-950 dark:text-white">
            {subs || 'Unavailable'}
          </div>
        </div>
        <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] p-6 space-y-1">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">Total Channel Views</div>
          <div className="font-mono-tabular text-2xl font-bold text-slate-950 dark:text-white">
            {totalViews || 'Unavailable'}
          </div>
        </div>
        <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] p-6 space-y-1">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">Published Videos</div>
          <div className="font-mono-tabular text-2xl font-bold text-slate-950 dark:text-white">
            {totalVideos || 'Unavailable'}
          </div>
        </div>
      </section>

      {/* Content Categories */}
      <section className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] p-6 sm:p-8 space-y-4">
        <h2 className="font-display text-xl font-bold text-slate-950 dark:text-white">Content Focus &amp; Categories</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm text-slate-700 dark:text-slate-300">
          {site.categories.map((cat, idx) => (
            <div
              key={cat}
              className="py-2.5 px-4 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-white/[0.02]"
            >
              <span className="font-mono-tabular text-xs text-slate-500 mr-2">0{idx + 1}.</span>
              <span className="font-medium">{cat}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Official Links */}
      <section className="flex flex-wrap items-center gap-4">
        <a
          href={site.youtubeChannelUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-semibold text-slate-950"
          style={{ backgroundColor: 'var(--brand-primary)' }}
        >
          <span>Visit YouTube Channel</span>
          <ExternalLink className="w-4 h-4" />
        </a>
        <a
          href={site.discordInviteUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-semibold border border-slate-300 dark:border-white/15 text-slate-900 dark:text-white"
        >
          <span>Join Discord Community</span>
          <ExternalLink className="w-4 h-4" />
        </a>
        <button
          type="button"
          onClick={() => navigate('/contact')}
          className="px-5 py-2.5 rounded-lg text-sm font-semibold text-slate-700 dark:text-slate-300 hover:underline"
        >
          Business &amp; Sponsorship Inquiries →
        </button>
      </section>
    </div>
  );
}
