import { CheckCircle2 } from 'lucide-react';
import React, { useState } from 'react';
import { useSite } from '../context/SiteContext';

export function ContactPage() {
  const { data } = useSite();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [inquiryType, setInquiryType] = useState<'Business' | 'Sponsorship' | 'Collaboration' | 'General'>('Business');
  const [company, setCompany] = useState('');
  const [message, setMessage] = useState('');
  const [website, setWebsite] = useState(''); // honeypot
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, inquiryType, company, message, website }),
      });
      const json = await res.json();
      if (!res.ok) {
        throw new Error(json.error || 'Failed to send inquiry.');
      }
      setSubmitted(true);
      setName('');
      setEmail('');
      setCompany('');
      setMessage('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Submission error.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12 sm:py-16 space-y-10">
      <div className="space-y-2">
        <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-950 dark:text-white">
          Contact &amp; Inquiries
        </h1>
        <p className="text-base text-slate-600 dark:text-slate-400">
          Reach out to {data?.site.channelName || 'the creator'} for business proposals, brand sponsorships, or
          collaborations.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-sm">
        <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] p-5 space-y-1">
          <div className="font-display font-bold text-slate-950 dark:text-white">Business</div>
          <p className="text-slate-600 dark:text-slate-400">Media licensing, press requests, and representation.</p>
        </div>
        <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] p-5 space-y-1">
          <div className="font-display font-bold text-slate-950 dark:text-white">Sponsorships</div>
          <p className="text-slate-600 dark:text-slate-400">Dedicated video integrations, Shorts, and livestreams.</p>
        </div>
        <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] p-5 space-y-1">
          <div className="font-display font-bold text-slate-950 dark:text-white">Collaborations</div>
          <p className="text-slate-600 dark:text-slate-400">Creator events, co-streams, and joint video projects.</p>
        </div>
      </div>

      {submitted ? (
        <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-8 space-y-4">
          <div className="flex items-center gap-3 text-emerald-600 dark:text-emerald-400 font-display text-xl font-bold">
            <CheckCircle2 className="w-6 h-6" />
            <span>Inquiry Received</span>
          </div>
          <p className="text-sm text-slate-700 dark:text-slate-300">
            Thank you for reaching out. Your message has been stored securely for review in the creator dashboard.
          </p>
          <button
            type="button"
            onClick={() => setSubmitted(false)}
            className="px-4 py-2 rounded-lg text-xs font-semibold border border-slate-300 dark:border-white/15"
          >
            Send another message
          </button>
        </div>
      ) : (
        <form
          onSubmit={handleSubmit}
          className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] p-6 sm:p-8 space-y-5"
        >
          {error && (
            <div role="alert" className="p-3.5 rounded-lg border border-red-500/30 bg-red-500/10 text-sm text-red-500">
              {error}
            </div>
          )}

          {/* Honeypot */}
          <input
            type="text"
            tabIndex={-1}
            autoComplete="off"
            value={website}
            onChange={(e) => setWebsite(e.target.value)}
            className="hidden"
            aria-hidden="true"
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <label className="block space-y-1.5 text-sm">
              <span className="font-medium text-slate-700 dark:text-slate-300">Your Name *</span>
              <input
                type="text"
                required
                minLength={2}
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Alex Rivera"
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#090b10] text-slate-900 dark:text-white focus:outline-none focus:border-[var(--brand-primary)]"
              />
            </label>

            <label className="block space-y-1.5 text-sm">
              <span className="font-medium text-slate-700 dark:text-slate-300">Email Address *</span>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="alex@company.com"
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#090b10] text-slate-900 dark:text-white focus:outline-none focus:border-[var(--brand-primary)]"
              />
            </label>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <label className="block space-y-1.5 text-sm">
              <span className="font-medium text-slate-700 dark:text-slate-300">Inquiry Category *</span>
              <select
                value={inquiryType}
                onChange={(e) => setInquiryType(e.target.value as typeof inquiryType)}
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#090b10] text-slate-900 dark:text-white focus:outline-none focus:border-[var(--brand-primary)]"
              >
                <option value="Business">Business Inquiry</option>
                <option value="Sponsorship">Sponsorship</option>
                <option value="Collaboration">Collaboration</option>
                <option value="General">General Question</option>
              </select>
            </label>

            <label className="block space-y-1.5 text-sm">
              <span className="font-medium text-slate-700 dark:text-slate-300">Organization / Brand</span>
              <input
                type="text"
                value={company}
                onChange={(e) => setCompany(e.target.value)}
                placeholder="Optional"
                className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#090b10] text-slate-900 dark:text-white focus:outline-none focus:border-[var(--brand-primary)]"
              />
            </label>
          </div>

          <label className="block space-y-1.5 text-sm">
            <span className="font-medium text-slate-700 dark:text-slate-300">Message *</span>
            <textarea
              required
              minLength={10}
              rows={5}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Share campaign timeline, deliverables, or collaboration details..."
              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#090b10] text-slate-900 dark:text-white focus:outline-none focus:border-[var(--brand-primary)]"
            />
          </label>

          <button
            type="submit"
            disabled={submitting}
            className="px-6 py-3 rounded-lg text-sm font-semibold text-slate-950 disabled:opacity-50"
            style={{ backgroundColor: 'var(--brand-primary)' }}
          >
            {submitting ? 'Sending...' : 'Submit Inquiry'}
          </button>
        </form>
      )}
    </div>
  );
}
