import { Search } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { VideoCard } from '../components/VideoCard';
import { VideoPlayerModal } from '../components/VideoPlayerModal';
import { useSite } from '../context/SiteContext';
import type { VideoItem } from '../types';

export function VideosPage() {
  const { data } = useSite();
  const [items, setItems] = useState<VideoItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const [sort, setSort] = useState<'latest' | 'popular'>('latest');
  const [category, setCategory] = useState<'videos_only' | 'all' | 'Livestream'>('videos_only');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);
  const [activeVideo, setActiveVideo] = useState<VideoItem | null>(null);

  const loadVideos = useCallback(async () => {
    setLoading(true);
    try {
      const qs = new URLSearchParams({
        q: query,
        sort,
        category,
        page: String(page),
        limit: '12',
      });
      const res = await fetch(`/api/videos?${qs.toString()}`);
      if (!res.ok) throw new Error('Failed to load videos');
      const json = await res.json();
      setItems(json.items || []);
      setTotalPages(json.totalPages || 1);
      setTotal(json.total || 0);
    } catch {
      setItems([]);
    } finally {
      setLoading(false);
    }
  }, [query, sort, category, page]);

  useEffect(() => {
    const timer = setTimeout(() => {
      loadVideos();
    }, 150);
    return () => clearTimeout(timer);
  }, [loadVideos]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12 space-y-8">
      <div className="space-y-2">
        <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-950 dark:text-white">
          Video Library
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-400">
          Browse {total.toLocaleString('en-US')} synchronized uploads from {data?.site.channelName || 'the channel'}.
        </p>
      </div>

      {/* Controls Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="search"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setPage(1);
            }}
            placeholder="Search video titles or descriptions..."
            aria-label="Search videos"
            className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-[var(--brand-primary)]"
          />
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1 p-1 rounded-lg bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10">
            {[
              { id: 'videos_only', label: 'Long-form' },
              { id: 'Livestream', label: 'Livestreams' },
              { id: 'all', label: 'All Items' },
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => {
                  setCategory(tab.id as typeof category);
                  setPage(1);
                }}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  category === tab.id
                    ? 'bg-white dark:bg-[#1a202c] text-slate-950 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1 p-1 rounded-lg bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10">
            {[
              { id: 'latest', label: 'Latest' },
              { id: 'popular', label: 'Popular' },
            ].map((s) => (
              <button
                key={s.id}
                type="button"
                onClick={() => {
                  setSort(s.id as typeof sort);
                  setPage(1);
                }}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  sort === s.id
                    ? 'bg-white dark:bg-[#1a202c] text-slate-950 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Video Grid */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, idx) => (
            <div key={idx} className="h-72 rounded-xl bg-slate-200 dark:bg-white/5 animate-pulse" />
          ))}
        </div>
      ) : items.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {items.map((video) => (
            <VideoCard key={video.id} video={video} onPlay={setActiveVideo} />
          ))}
        </div>
      ) : (
        <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] p-12 text-center space-y-2">
          <h2 className="font-display text-lg font-semibold text-slate-900 dark:text-white">No matching videos found</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Try clearing your search query or switching category filters.
          </p>
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-3 pt-4">
          <button
            type="button"
            disabled={page <= 1}
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            className="px-4 py-2 text-xs font-semibold rounded-lg border border-slate-200 dark:border-white/10 disabled:opacity-40"
          >
            Previous
          </button>
          <span className="font-mono-tabular text-xs text-slate-500 dark:text-slate-400">
            Page {page} of {totalPages}
          </span>
          <button
            type="button"
            disabled={page >= totalPages}
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            className="px-4 py-2 text-xs font-semibold rounded-lg border border-slate-200 dark:border-white/10 disabled:opacity-40"
          >
            Next
          </button>
        </div>
      )}

      <VideoPlayerModal video={activeVideo} onClose={() => setActiveVideo(null)} />
    </div>
  );
}
