import { Check, Copy, LogOut, RefreshCw, Shield, Star, Trash2 } from 'lucide-react';
import React, { useCallback, useEffect, useState } from 'react';
import { useSite } from '../context/SiteContext';
import { formatCompactNumber, formatRelativeDate, type ChannelStats, type SiteConfig, type VideoItem } from '../types';

interface ContactSubmission {
  id: number;
  name: string;
  email: string;
  inquiry_type: string;
  company: string;
  message: string;
  is_read: number;
  created_at: string;
}

interface SyncLogRow {
  id: number;
  sync_type: string;
  status: string;
  message: string;
  created_at: string;
}

interface DashboardPayload {
  site: SiteConfig;
  stats: ChannelStats;
  contacts: ContactSubmission[];
  logs: SyncLogRow[];
  videos: VideoItem[];
  deployment: { envFile: string; pm2Config: string; port: number };
  runtime: {
    activePort: number;
    nodeVersion: string;
    youtubeApiConfigured: boolean;
    geminiApiConfigured: boolean;
    subscriberRefreshIntervalMs: number;
    videoRefreshIntervalMs: number;
    liveRefreshIntervalMs: number;
  };
}

export function AdminPage() {
  const { refreshSite } = useSite();
  const [authLoading, setAuthLoading] = useState(true);
  const [needsSetup, setNeedsSetup] = useState(false);
  const [authenticated, setAuthenticated] = useState(false);
  const [csrfToken, setCsrfToken] = useState<string | null>(null);
  const [adminUsername, setAdminUsername] = useState<string | null>(null);

  const [usernameInput, setUsernameInput] = useState('admin');
  const [passwordInput, setPasswordInput] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [authSubmitting, setAuthSubmitting] = useState(false);

  const [tab, setTab] = useState<'overview' | 'videos' | 'branding' | 'contacts' | 'deployment'>('overview');
  const [dashboard, setDashboard] = useState<DashboardPayload | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [savingSettings, setSavingSettings] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  // Editable branding & site settings state
  const [formState, setFormState] = useState<SiteConfig | null>(null);
  const [socialTwitter, setSocialTwitter] = useState('');
  const [socialInstagram, setSocialInstagram] = useState('');
  const [socialTwitch, setSocialTwitch] = useState('');
  const [socialTiktok, setSocialTiktok] = useState('');

  const checkAuthStatus = useCallback(async () => {
    setAuthLoading(true);
    try {
      const res = await fetch('/api/admin/status');
      const json = await res.json();
      setNeedsSetup(Boolean(json.needsSetup));
      setAuthenticated(Boolean(json.authenticated));
      setCsrfToken(json.csrfToken || null);
      setAdminUsername(json.username || null);
    } finally {
      setAuthLoading(false);
    }
  }, []);

  const loadDashboard = useCallback(async () => {
    const res = await fetch('/api/admin/dashboard');
    if (res.status === 401) {
      setAuthenticated(false);
      return;
    }
    if (!res.ok) return;
    const json = (await res.json()) as DashboardPayload;
    setDashboard(json);
    setFormState(json.site);
    setSocialTwitter(json.site.socialLinks?.twitter || '');
    setSocialInstagram(json.site.socialLinks?.instagram || '');
    setSocialTwitch(json.site.socialLinks?.twitch || '');
    setSocialTiktok(json.site.socialLinks?.tiktok || '');
  }, []);

  useEffect(() => {
    checkAuthStatus();
  }, [checkAuthStatus]);

  useEffect(() => {
    if (authenticated) {
      loadDashboard();
    }
  }, [authenticated, loadDashboard]);

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthSubmitting(true);
    try {
      const endpoint = needsSetup ? '/api/admin/setup' : '/api/admin/login';
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: usernameInput, password: passwordInput }),
      });
      const json = await res.json();
      if (!res.ok) {
        throw new Error(json.error || 'Authentication failed.');
      }
      setNeedsSetup(false);
      setAuthenticated(true);
      setCsrfToken(json.csrfToken);
      setAdminUsername(json.username);
      setPasswordInput('');
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'Login error.');
    } finally {
      setAuthSubmitting(false);
    }
  };

  const handleLogout = async () => {
    await fetch('/api/admin/logout', { method: 'POST' });
    setAuthenticated(false);
    setDashboard(null);
    setCsrfToken(null);
  };

  const triggerRefresh = async (rebrand = false) => {
    if (!csrfToken) return;
    setRefreshing(true);
    setNotice(null);
    try {
      const res = await fetch('/api/admin/refresh', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': csrfToken,
        },
        body: JSON.stringify({ scope: 'all', rebrand }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Refresh failed');
      await Promise.all([loadDashboard(), refreshSite()]);
      setNotice(
        json.error
          ? `Sync completed with fallback notice: ${json.error}`
          : rebrand
            ? 'Channel data refreshed and AI branding updated.'
            : 'Channel data synchronized successfully.'
      );
    } catch (err) {
      setNotice(err instanceof Error ? err.message : 'Sync failed.');
    } finally {
      setRefreshing(false);
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!csrfToken || !formState) return;
    setSavingSettings(true);
    setNotice(null);
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': csrfToken,
        },
        body: JSON.stringify({
          channelName: formState.channelName,
          youtubeChannelUrl: formState.youtubeChannelUrl,
          discordInviteUrl: formState.discordInviteUrl,
          desiredPort: Number(formState.desiredPort),
          niche: formState.niche,
          categories: formState.categories,
          heroHeadline: formState.heroHeadline,
          heroSubheadline: formState.heroSubheadline,
          aboutText: formState.aboutText,
          communityPitch: formState.communityPitch,
          themeMode: formState.themeMode,
          primaryColor: formState.primaryColor,
          secondaryColor: formState.secondaryColor,
          accentColor: formState.accentColor,
          fontDisplay: formState.fontDisplay,
          fontBody: formState.fontBody,
          socialLinks: {
            twitter: socialTwitter.trim(),
            instagram: socialInstagram.trim(),
            twitch: socialTwitch.trim(),
            tiktok: socialTiktok.trim(),
          },
        }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Failed to save settings.');
      await Promise.all([loadDashboard(), refreshSite()]);
      setNotice('Website settings and branding saved.');
    } catch (err) {
      setNotice(err instanceof Error ? err.message : 'Save failed.');
    } finally {
      setSavingSettings(false);
    }
  };

  const setFeaturedVideo = async (videoId: string | null) => {
    if (!csrfToken) return;
    await fetch('/api/admin/featured', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': csrfToken,
      },
      body: JSON.stringify({ videoId }),
    });
    await Promise.all([loadDashboard(), refreshSite()]);
  };

  const toggleContactRead = async (c: ContactSubmission) => {
    if (!csrfToken) return;
    await fetch(`/api/admin/contacts/${c.id}`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': csrfToken,
      },
      body: JSON.stringify({ isRead: !c.is_read }),
    });
    await loadDashboard();
  };

  const deleteContact = async (id: number) => {
    if (!csrfToken) return;
    await fetch(`/api/admin/contacts/${id}`, {
      method: 'DELETE',
      headers: { 'X-CSRF-Token': csrfToken },
    });
    await loadDashboard();
  };

  const copyConfig = (key: string, text: string) => {
    navigator.clipboard?.writeText(text);
    setCopied(key);
    setTimeout(() => setCopied(null), 1800);
  };

  if (authLoading) {
    return (
      <div className="max-w-md mx-auto px-4 py-20">
        <div className="h-64 rounded-xl bg-slate-200 dark:bg-white/5 animate-pulse" />
      </div>
    );
  }

  if (!authenticated) {
    return (
      <div className="max-w-md mx-auto px-4 py-16">
        <form
          onSubmit={handleAuthSubmit}
          className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] p-8 space-y-5"
        >
          <div className="flex items-center gap-2.5">
            <Shield className="w-5 h-5 text-[var(--brand-primary)]" />
            <h1 className="font-display text-2xl font-bold text-slate-950 dark:text-white">
              {needsSetup ? 'Create Admin Account' : 'Admin Sign In'}
            </h1>
          </div>

          <p className="text-sm text-slate-600 dark:text-slate-400">
            {needsSetup
              ? 'No admin account exists yet. Set a secure username and password (min 8 characters) to protect the creator dashboard.'
              : 'Sign in with your administrator credentials to manage channel content, branding, and inquiries.'}
          </p>

          {authError && (
            <div role="alert" className="p-3 rounded-lg border border-red-500/30 bg-red-500/10 text-sm text-red-500">
              {authError}
            </div>
          )}

          <label className="block space-y-1.5 text-sm">
            <span className="font-medium text-slate-700 dark:text-slate-300">Username</span>
            <input
              type="text"
              required
              minLength={3}
              value={usernameInput}
              onChange={(e) => setUsernameInput(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#090b10] text-slate-900 dark:text-white"
            />
          </label>

          <label className="block space-y-1.5 text-sm">
            <span className="font-medium text-slate-700 dark:text-slate-300">Password</span>
            <input
              type="password"
              required
              minLength={8}
              value={passwordInput}
              onChange={(e) => setPasswordInput(e.target.value)}
              placeholder="Minimum 8 characters"
              className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#090b10] text-slate-900 dark:text-white"
            />
          </label>

          <button
            type="submit"
            disabled={authSubmitting}
            className="w-full py-2.5 rounded-lg text-sm font-semibold text-slate-950 disabled:opacity-50"
            style={{ backgroundColor: 'var(--brand-primary)' }}
          >
            {authSubmitting ? 'Please wait...' : needsSetup ? 'Create Admin Account' : 'Sign In'}
          </button>
        </form>
      </div>
    );
  }

  if (!dashboard || !formState) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="h-96 rounded-xl bg-slate-200 dark:bg-white/5 animate-pulse" />
      </div>
    );
  }

  const unreadCount = dashboard.contacts.filter((c) => !c.is_read).length;
  const shortsCount = dashboard.videos.filter((v) => v.isShort).length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 space-y-8">
      {/* Admin Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-white/10">
        <div>
          <div className="text-xs text-slate-500 dark:text-slate-400">
            Admin Console · Signed in as {adminUsername}
          </div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-950 dark:text-white">
            {dashboard.site.channelName} Management
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            disabled={refreshing}
            onClick={() => triggerRefresh(false)}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold text-slate-950 disabled:opacity-50 whitespace-nowrap shrink-0"
            style={{ backgroundColor: 'var(--brand-primary)' }}
          >
            <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
            <span>{refreshing ? 'Syncing...' : 'Refresh YouTube Data'}</span>
          </button>
          <button
            type="button"
            onClick={handleLogout}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold border border-slate-300 dark:border-white/15 text-slate-700 dark:text-slate-300 whitespace-nowrap shrink-0"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>

      {notice && (
        <div className="p-3.5 rounded-lg border border-slate-200 dark:border-white/15 bg-white dark:bg-[#11151e] text-sm text-slate-800 dark:text-slate-200">
          {notice}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Sidebar Nav */}
        <aside className="lg:col-span-3 space-y-1">
          {[
            { id: 'overview', label: 'Overview & Sync' },
            { id: 'videos', label: `Videos & Featured (${dashboard.videos.length})` },
            { id: 'branding', label: 'Branding & Copy' },
            { id: 'contacts', label: `Contact Inbox (${unreadCount} unread)` },
            { id: 'deployment', label: 'Port & VPS Deployment' },
          ].map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setTab(item.id as typeof tab)}
              className={`w-full text-left px-4 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                tab === item.id
                  ? 'bg-slate-900 text-white dark:bg-white/10'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/5'
              }`}
            >
              {item.label}
            </button>
          ))}
        </aside>

        {/* Main Panel */}
        <div className="lg:col-span-9 space-y-6">
          {tab === 'overview' && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] p-5">
                  <div className="text-xs text-slate-500">Subscribers</div>
                  <div className="font-mono-tabular text-xl font-bold mt-1">
                    {dashboard.stats.subscriberCount !== null
                      ? formatCompactNumber(dashboard.stats.subscriberCount)
                      : dashboard.stats.subscriberDisplay || 'Unavailable'}
                  </div>
                </div>
                <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] p-5">
                  <div className="text-xs text-slate-500">Synced Videos</div>
                  <div className="font-mono-tabular text-xl font-bold mt-1">{dashboard.videos.length}</div>
                </div>
                <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] p-5">
                  <div className="text-xs text-slate-500">Verified Shorts</div>
                  <div className="font-mono-tabular text-xl font-bold mt-1">{shortsCount}</div>
                </div>
                <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] p-5">
                  <div className="text-xs text-slate-500">Stream Status</div>
                  <div className="font-display text-xl font-bold mt-1">
                    {dashboard.stats.isLive ? 'LIVE' : 'Offline'}
                  </div>
                </div>
              </div>

              <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] p-6 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <h2 className="font-display text-lg font-bold">API &amp; Worker Configuration</h2>
                  <button
                    type="button"
                    disabled={refreshing}
                    onClick={() => triggerRefresh(true)}
                    className="px-4 py-2 rounded-lg text-xs font-semibold border border-slate-300 dark:border-white/15"
                  >
                    Re-analyze Niche &amp; AI Branding
                  </button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                  <div className="p-3.5 rounded-lg border border-slate-200 dark:border-white/10">
                    <div className="text-xs text-slate-500">YouTube Data API v3</div>
                    <div className="font-semibold mt-0.5">
                      {dashboard.runtime.youtubeApiConfigured
                        ? 'Configured (Official API)'
                        : 'Public Feed Fallback (Set YOUTUBE_API_KEY in .env for exact API stats)'}
                    </div>
                  </div>
                  <div className="p-3.5 rounded-lg border border-slate-200 dark:border-white/10">
                    <div className="text-xs text-slate-500">AI Brand Analyzer</div>
                    <div className="font-semibold mt-0.5">
                      {dashboard.runtime.geminiApiConfigured ? 'Active (Gemini Server-Side)' : 'Deterministic Niche Engine'}
                    </div>
                  </div>
                </div>
              </div>

              <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] overflow-hidden">
                <div className="px-6 py-4 border-b border-slate-200 dark:border-white/10 font-display font-bold">
                  Recent Sync Activity
                </div>
                <div className="divide-y divide-slate-200 dark:divide-white/10 max-h-72 overflow-y-auto">
                  {dashboard.logs.map((log) => (
                    <div key={log.id} className="px-6 py-3 text-xs flex items-center justify-between gap-4">
                      <div className="min-w-0">
                        <span className="font-mono-tabular font-semibold uppercase mr-2">[{log.status}]</span>
                        <span className="font-medium mr-2">{log.sync_type}:</span>
                        <span className="text-slate-600 dark:text-slate-400">{log.message}</span>
                      </div>
                      <span className="font-mono-tabular text-slate-400 shrink-0">
                        {formatRelativeDate(log.created_at)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {tab === 'videos' && (
            <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] overflow-hidden">
              <div className="px-6 py-4 border-b border-slate-200 dark:border-white/10 flex items-center justify-between">
                <h2 className="font-display font-bold">Manage Featured Video</h2>
                {dashboard.site.featuredVideoId && (
                  <button
                    type="button"
                    onClick={() => setFeaturedVideo(null)}
                    className="text-xs font-semibold text-slate-500 hover:text-slate-900 dark:hover:text-white"
                  >
                    Reset to latest upload
                  </button>
                )}
              </div>
              <div className="divide-y divide-slate-200 dark:divide-white/10">
                {dashboard.videos.map((v) => {
                  const isFeat = dashboard.site.featuredVideoId === v.id || v.isFeatured;
                  return (
                    <div key={v.id} className="p-4 flex items-center justify-between gap-4">
                      <div className="flex items-center gap-3 min-w-0">
                        <img
                          src={v.thumbnailUrl}
                          alt={v.title}
                          referrerPolicy="no-referrer"
                          className="w-20 h-12 rounded object-cover bg-slate-900 shrink-0"
                        />
                        <div className="min-w-0">
                          <div className="text-sm font-semibold truncate">{v.title}</div>
                          <div className="text-xs text-slate-500">
                            {v.isShort ? 'Verified Short' : v.category} · {formatRelativeDate(v.publishedAt)}
                          </div>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setFeaturedVideo(isFeat ? null : v.id)}
                        className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0 ${
                          isFeat
                            ? 'text-slate-950'
                            : 'border border-slate-300 dark:border-white/15 text-slate-700 dark:text-slate-300'
                        }`}
                        style={isFeat ? { backgroundColor: 'var(--brand-primary)' } : undefined}
                      >
                        <Star className="w-3.5 h-3.5" />
                        <span>{isFeat ? 'Featured' : 'Set Featured'}</span>
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {tab === 'branding' && (
            <form
              onSubmit={handleSaveSettings}
              className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] p-6 space-y-5"
            >
              <h2 className="font-display text-lg font-bold">Website Text, Links &amp; Theme</h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                <label className="block space-y-1">
                  <span className="font-medium">Channel Name</span>
                  <input
                    type="text"
                    required
                    value={formState.channelName}
                    onChange={(e) => setFormState({ ...formState, channelName: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#090b10]"
                  />
                </label>
                <label className="block space-y-1">
                  <span className="font-medium">Creator Niche</span>
                  <input
                    type="text"
                    required
                    value={formState.niche}
                    onChange={(e) => setFormState({ ...formState, niche: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#090b10]"
                  />
                </label>
                <label className="block space-y-1">
                  <span className="font-medium">Discord Invite URL</span>
                  <input
                    type="url"
                    required
                    value={formState.discordInviteUrl}
                    onChange={(e) => setFormState({ ...formState, discordInviteUrl: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#090b10]"
                  />
                </label>
                <label className="block space-y-1">
                  <span className="font-medium">Desired VPS Port</span>
                  <input
                    type="number"
                    min={1024}
                    max={65535}
                    value={formState.desiredPort}
                    onChange={(e) => setFormState({ ...formState, desiredPort: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#090b10] font-mono-tabular"
                  />
                </label>
              </div>

              <label className="block space-y-1 text-sm">
                <span className="font-medium">Hero Headline</span>
                <input
                  type="text"
                  required
                  value={formState.heroHeadline}
                  onChange={(e) => setFormState({ ...formState, heroHeadline: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#090b10]"
                />
              </label>

              <label className="block space-y-1 text-sm">
                <span className="font-medium">Hero Subheadline</span>
                <textarea
                  rows={2}
                  required
                  value={formState.heroSubheadline}
                  onChange={(e) => setFormState({ ...formState, heroSubheadline: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#090b10]"
                />
              </label>

              <label className="block space-y-1 text-sm">
                <span className="font-medium">About Text</span>
                <textarea
                  rows={3}
                  required
                  value={formState.aboutText}
                  onChange={(e) => setFormState({ ...formState, aboutText: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#090b10]"
                />
              </label>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
                <label className="block space-y-1">
                  <span className="font-medium">Theme Mode</span>
                  <select
                    value={formState.themeMode}
                    onChange={(e) => setFormState({ ...formState, themeMode: e.target.value as 'dark' | 'light' })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#090b10]"
                  >
                    <option value="dark">Dark</option>
                    <option value="light">Light</option>
                  </select>
                </label>
                <label className="block space-y-1">
                  <span className="font-medium">Primary Color</span>
                  <input
                    type="color"
                    value={formState.primaryColor}
                    onChange={(e) => setFormState({ ...formState, primaryColor: e.target.value })}
                    className="w-full h-10 rounded-lg border border-slate-200 dark:border-white/10 cursor-pointer"
                  />
                </label>
                <label className="block space-y-1">
                  <span className="font-medium">Display Font</span>
                  <select
                    value={formState.fontDisplay}
                    onChange={(e) => setFormState({ ...formState, fontDisplay: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#090b10]"
                  >
                    <option value="Outfit">Outfit</option>
                    <option value="Barlow Condensed">Barlow Condensed</option>
                    <option value="Bricolage Grotesque">Bricolage Grotesque</option>
                    <option value="Archivo">Archivo</option>
                    <option value="Playfair Display">Playfair Display</option>
                  </select>
                </label>
                <label className="block space-y-1">
                  <span className="font-medium">Body Font</span>
                  <select
                    value={formState.fontBody}
                    onChange={(e) => setFormState({ ...formState, fontBody: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#090b10]"
                  >
                    <option value="Plus Jakarta Sans">Plus Jakarta Sans</option>
                    <option value="DM Sans">DM Sans</option>
                    <option value="Manrope">Manrope</option>
                    <option value="Public Sans">Public Sans</option>
                    <option value="Source Serif 4">Source Serif 4</option>
                  </select>
                </label>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm pt-2">
                <label className="block space-y-1">
                  <span className="font-medium">X / Twitter URL</span>
                  <input
                    type="url"
                    value={socialTwitter}
                    onChange={(e) => setSocialTwitter(e.target.value)}
                    placeholder="https://x.com/..."
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#090b10]"
                  />
                </label>
                <label className="block space-y-1">
                  <span className="font-medium">Instagram URL</span>
                  <input
                    type="url"
                    value={socialInstagram}
                    onChange={(e) => setSocialInstagram(e.target.value)}
                    placeholder="https://instagram.com/..."
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#090b10]"
                  />
                </label>
                <label className="block space-y-1">
                  <span className="font-medium">Twitch URL</span>
                  <input
                    type="url"
                    value={socialTwitch}
                    onChange={(e) => setSocialTwitch(e.target.value)}
                    placeholder="https://twitch.tv/..."
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#090b10]"
                  />
                </label>
                <label className="block space-y-1">
                  <span className="font-medium">TikTok URL</span>
                  <input
                    type="url"
                    value={socialTiktok}
                    onChange={(e) => setSocialTiktok(e.target.value)}
                    placeholder="https://tiktok.com/@..."
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#090b10]"
                  />
                </label>
              </div>

              <button
                type="submit"
                disabled={savingSettings}
                className="px-6 py-2.5 rounded-lg text-sm font-semibold text-slate-950 disabled:opacity-50"
                style={{ backgroundColor: 'var(--brand-primary)' }}
              >
                {savingSettings ? 'Saving...' : 'Save Settings'}
              </button>
            </form>
          )}

          {tab === 'contacts' && (
            <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] overflow-hidden">
              <div className="px-6 py-4 border-b border-slate-200 dark:border-white/10 font-display font-bold">
                Contact Form Submissions
              </div>
              {dashboard.contacts.length === 0 ? (
                <div className="p-8 text-sm text-slate-500">No inquiries submitted yet.</div>
              ) : (
                <div className="divide-y divide-slate-200 dark:divide-white/10">
                  {dashboard.contacts.map((c) => (
                    <div key={c.id} className="p-5 space-y-2">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="text-sm font-semibold">
                          {c.name} · <span className="text-slate-500 font-normal">{c.email}</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs">
                          <span className="text-slate-500">
                            {c.inquiry_type} · {formatRelativeDate(c.created_at)}
                          </span>
                          <button
                            type="button"
                            onClick={() => toggleContactRead(c)}
                            className="px-2.5 py-1 rounded border border-slate-300 dark:border-white/15"
                          >
                            {c.is_read ? 'Mark Unread' : 'Mark Read'}
                          </button>
                          <button
                            type="button"
                            onClick={() => deleteContact(c.id)}
                            aria-label="Delete submission"
                            className="p-1.5 text-red-500 hover:bg-red-500/10 rounded"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                      {c.company && <div className="text-xs text-slate-500">Organization: {c.company}</div>}
                      <p className="text-sm text-slate-700 dark:text-slate-300 whitespace-pre-line">{c.message}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {tab === 'deployment' && (
            <div className="space-y-6">
              <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] p-6 space-y-2 text-sm">
                <h2 className="font-display text-lg font-bold">Server &amp; Port Runtime</h2>
                <p className="text-slate-600 dark:text-slate-400">
                  Active runtime port: <strong className="font-mono-tabular">{dashboard.runtime.activePort}</strong> ·
                  Target VPS port: <strong className="font-mono-tabular">{dashboard.deployment.port}</strong> · Node{' '}
                  <strong className="font-mono-tabular">{dashboard.runtime.nodeVersion}</strong>
                </p>
              </div>

              <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] overflow-hidden">
                <div className="px-4 py-3 border-b border-slate-200 dark:border-white/10 flex items-center justify-between">
                  <span className="font-mono-tabular text-xs font-semibold">.env Configuration</span>
                  <button
                    type="button"
                    onClick={() => copyConfig('env', dashboard.deployment.envFile)}
                    className="inline-flex items-center gap-1 text-xs font-medium"
                  >
                    {copied === 'env' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied === 'env' ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <pre className="p-4 text-xs font-mono-tabular overflow-x-auto">{dashboard.deployment.envFile}</pre>
              </div>

              <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] overflow-hidden">
                <div className="px-4 py-3 border-b border-slate-200 dark:border-white/10 flex items-center justify-between">
                  <span className="font-mono-tabular text-xs font-semibold">ecosystem.config.cjs (PM2)</span>
                  <button
                    type="button"
                    onClick={() => copyConfig('pm2', dashboard.deployment.pm2Config)}
                    className="inline-flex items-center gap-1 text-xs font-medium"
                  >
                    {copied === 'pm2' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied === 'pm2' ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <pre className="p-4 text-xs font-mono-tabular overflow-x-auto">{dashboard.deployment.pm2Config}</pre>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
