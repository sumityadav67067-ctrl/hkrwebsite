import { ExternalLink, Play } from 'lucide-react';
import { useEffect, useState } from 'react';
import { VideoPlayerModal } from '../components/VideoPlayerModal';
import { useSite } from '../context/SiteContext';
import { formatCompactNumber, formatRelativeDate, type VideoItem } from '../types';

export function ShortsPage() {
  const { data } = useSite();
  const [shorts, setShorts] = useState<VideoItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeShort, setActiveShort] = useState<VideoItem | null>(null);
  const [playingInlineId, setPlayingInlineId] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    fetch('/api/shorts')
      .then((res) => res.json())
      .then((json) => {
        if (active) setShorts(json.items || []);
      })
      .catch(() => {
        if (active) setShorts([]);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [data?.stats.lastVideoSync]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12 space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div className="space-y-2">
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-950 dark:text-white">
            YouTube Shorts
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Verified vertical Shorts from {data?.site.channelName || 'the channel'}. Automatically refreshed as new
            Shorts are published.
          </p>
        </div>
        {data?.site.youtubeChannelUrl && (
          <a
            href={`${data.site.youtubeChannelUrl.replace(/\/+$/, '')}/shorts`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold border border-slate-300 dark:border-white/15 text-slate-900 dark:text-white whitespace-nowrap shrink-0"
          >
            <span>Open Shorts on YouTube</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        )}
      </div>

      {loading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-5">
          {Array.from({ length: 4 }).map((_, idx) => (
            <div key={idx} className="aspect-[9/16] rounded-xl bg-slate-200 dark:bg-white/5 animate-pulse" />
          ))}
        </div>
      ) : shorts.length > 0 ? (
        <>
          {/* Desktop Multi-Column Vertical Gallery */}
          <div className="hidden sm:grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {shorts.map((short) => {
              const views = formatCompactNumber(short.viewCount);
              return (
                <article
                  key={short.id}
                  className="group flex flex-col rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] overflow-hidden"
                >
                  <button
                    type="button"
                    onClick={() => setActiveShort(short)}
                    className="relative aspect-[9/16] w-full overflow-hidden bg-slate-900"
                    aria-label={`Play Short: ${short.title}`}
                  >
                    <img
                      src={short.thumbnailUrl}
                      alt={short.title}
                      loading="lazy"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/15 to-transparent" />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="w-12 h-12 rounded-full bg-black/70 border border-white/25 text-white flex items-center justify-center transition-transform group-hover:scale-110">
                        <Play className="w-5 h-5 fill-current ml-0.5" />
                      </span>
                    </div>
                  </button>

                  <div className="p-4 flex-1 flex flex-col justify-between gap-3">
                    <div className="space-y-1">
                      <div className="text-xs text-slate-500 dark:text-slate-400">
                        <span>{formatRelativeDate(short.publishedAt)}</span>
                        {views && (
                          <>
                            <span className="mx-1.5" aria-hidden="true">
                              ·
                            </span>
                            <span className="tabular-nums">{views} views</span>
                          </>
                        )}
                      </div>
                      <h2 className="font-display text-sm font-semibold text-slate-900 dark:text-white line-clamp-2">
                        {short.title}
                      </h2>
                    </div>

                    <a
                      href={`https://www.youtube.com/shorts/${short.id}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs font-semibold text-slate-600 dark:text-slate-300 hover:underline"
                    >
                      Watch on YouTube Shorts →
                    </a>
                  </div>
                </article>
              );
            })}
          </div>

          {/* Mobile Touch-Friendly Vertical Snap Gallery */}
          <div className="sm:hidden space-y-6 snap-y snap-mandatory">
            {shorts.map((short) => {
              const isPlaying = playingInlineId === short.id;
              const views = formatCompactNumber(short.viewCount);
              return (
                <article
                  key={`mob-${short.id}`}
                  className="snap-start rounded-xl border border-slate-200 dark:border-white/10 bg-black overflow-hidden"
                >
                  <div className="relative aspect-[9/16] w-full">
                    {isPlaying ? (
                      <iframe
                        src={`https://www.youtube.com/embed/${short.id}?autoplay=1&rel=0`}
                        title={short.title}
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                        className="w-full h-full"
                      />
                    ) : (
                      <button
                        type="button"
                        onClick={() => setPlayingInlineId(short.id)}
                        className="relative w-full h-full text-left"
                      >
                        <img
                          src={short.thumbnailUrl}
                          alt={short.title}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" />
                        <div className="absolute inset-0 flex items-center justify-center">
                          <span className="w-14 h-14 rounded-full bg-black/75 border border-white/30 text-white flex items-center justify-center">
                            <Play className="w-6 h-6 fill-current ml-0.5" />
                          </span>
                        </div>
                        <div className="absolute inset-x-0 bottom-0 p-5 text-white space-y-1">
                          <div className="text-xs text-slate-300">
                            {formatRelativeDate(short.publishedAt)}
                            {views && ` · ${views} views`}
                          </div>
                          <h2 className="font-display text-base font-semibold">{short.title}</h2>
                        </div>
                      </button>
                    )}
                  </div>
                  <div className="px-4 py-3 bg-[#11151e] flex items-center justify-between text-xs text-slate-300">
                    <span className="truncate pr-3">{short.title}</span>
                    <a
                      href={`https://www.youtube.com/shorts/${short.id}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="font-semibold text-amber-400 whitespace-nowrap shrink-0"
                    >
                      YouTube →
                    </a>
                  </div>
                </article>
              );
            })}
          </div>
        </>
      ) : (
        <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] p-10 space-y-3">
          <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">No Verified Shorts Yet</h2>
          <p className="text-sm text-slate-600 dark:text-slate-400 max-w-xl">
            No confirmed YouTube Shorts were detected in recent uploads. Long-form videos are never shown here without
            Shorts verification.
          </p>
        </div>
      )}

      <VideoPlayerModal video={activeShort} onClose={() => setActiveShort(null)} />
    </div>
  );
}
