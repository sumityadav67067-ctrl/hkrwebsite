import { ExternalLink, Radio } from 'lucide-react';
import { useEffect, useState } from 'react';
import { VideoCard } from '../components/VideoCard';
import { VideoPlayerModal } from '../components/VideoPlayerModal';
import { useSite } from '../context/SiteContext';
import { formatRelativeDate, type UpcomingLiveItem, type VideoItem } from '../types';

interface LivePayload {
  isLive: boolean;
  liveVideoId: string | null;
  liveTitle: string | null;
  liveThumbnail: string | null;
  liveStartedAt: string | null;
  liveViewers: number | null;
  upcomingLive: UpcomingLiveItem[];
  lastLiveSync: string | null;
  recentLivestreams: VideoItem[];
  latestUploads: VideoItem[];
}

export function LivePage() {
  const { data } = useSite();
  const [liveData, setLiveData] = useState<LivePayload | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeVideo, setActiveVideo] = useState<VideoItem | null>(null);

  useEffect(() => {
    let mounted = true;
    fetch('/api/live')
      .then((res) => res.json())
      .then((json: LivePayload) => {
        if (mounted) setLiveData(json);
      })
      .catch(() => {})
      .finally(() => {
        if (mounted) setLoading(false);
      });
    return () => {
      mounted = false;
    };
  }, [data?.stats.lastLiveSync, data?.stats.isLive]);

  const site = data?.site;
  const subscribeHref = site?.youtubeChannelUrl
    ? site.youtubeChannelUrl.includes('?')
      ? `${site.youtubeChannelUrl}&sub_confirmation=1`
      : `${site.youtubeChannelUrl}?sub_confirmation=1`
    : 'https://www.youtube.com';

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12 space-y-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-950 dark:text-white">
              Live Stream
            </h1>
            {liveData?.isLive ? (
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-red-600 text-white text-xs font-bold tracking-wider">
                <Radio className="w-3.5 h-3.5" />
                LIVE
              </span>
            ) : (
              <span className="px-2.5 py-1 rounded border border-slate-300 dark:border-white/15 text-slate-600 dark:text-slate-300 text-xs font-semibold">
                OFFLINE
              </span>
            )}
          </div>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Automatic broadcast detection for {site?.channelName || 'the channel'}
            {liveData?.lastLiveSync ? ` · Last checked ${formatRelativeDate(liveData.lastLiveSync)}` : ''}.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {site?.discordInviteUrl && (
            <a
              href={site.discordInviteUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-semibold border border-slate-300 dark:border-white/15 text-slate-900 dark:text-white whitespace-nowrap shrink-0"
            >
              <span>Join Discord</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          )}
          <a
            href={subscribeHref}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-semibold text-slate-950 whitespace-nowrap shrink-0"
            style={{ backgroundColor: 'var(--brand-primary)' }}
          >
            <span>Subscribe</span>
          </a>
        </div>
      </div>

      {loading ? (
        <div className="aspect-video rounded-xl bg-slate-200 dark:bg-white/5 animate-pulse" />
      ) : liveData?.isLive && liveData.liveVideoId ? (
        <section className="rounded-xl border border-red-500/40 bg-black overflow-hidden">
          <div className="aspect-video w-full">
            <iframe
              src={`https://www.youtube.com/embed/${liveData.liveVideoId}?autoplay=1&rel=0`}
              title={liveData.liveTitle || 'Live Stream'}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="w-full h-full"
            />
          </div>
          <div className="p-6 bg-[#11151e] text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <h2 className="font-display text-xl font-bold">{liveData.liveTitle || 'Live Stream'}</h2>
              <div className="text-xs text-slate-400">
                {liveData.liveStartedAt && <span>Started {formatRelativeDate(liveData.liveStartedAt)}</span>}
                {liveData.liveViewers !== null && (
                  <>
                    <span className="mx-2" aria-hidden="true">
                      ·
                    </span>
                    <span className="tabular-nums">{liveData.liveViewers.toLocaleString('en-US')} watching now</span>
                  </>
                )}
              </div>
            </div>
            <a
              href={`https://www.youtube.com/watch?v=${liveData.liveVideoId}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold bg-red-600 text-white whitespace-nowrap shrink-0"
            >
              <span>Watch on YouTube</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </section>
      ) : (
        <section className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] p-8 sm:p-10 space-y-4">
          <h2 className="font-display text-2xl font-bold text-slate-950 dark:text-white">
            {site?.channelName || 'Creator'} is currently offline
          </h2>
          <p className="text-sm sm:text-base text-slate-600 dark:text-slate-400 max-w-2xl">
            No active public livestream is currently detected on YouTube. Join Discord for go-live alerts or browse
            recent uploads below.
          </p>
        </section>
      )}

      {/* Upcoming Livestreams */}
      {liveData && liveData.upcomingLive.length > 0 && (
        <section className="space-y-5">
          <h2 className="font-display text-2xl font-bold text-slate-950 dark:text-white">Upcoming Streams</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {liveData.upcomingLive.map((item) => (
              <a
                key={item.id}
                href={`https://www.youtube.com/watch?v=${item.id}`}
                target="_blank"
                rel="noopener noreferrer"
                className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] overflow-hidden hover:border-slate-300 dark:hover:border-white/20"
              >
                <div className="aspect-video bg-slate-900">
                  <img
                    src={item.thumbnail}
                    alt={item.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-4 space-y-1">
                  <div className="text-xs text-slate-500 dark:text-slate-400">
                    {item.scheduledStartTime
                      ? `Scheduled: ${new Date(item.scheduledStartTime).toLocaleString()}`
                      : 'Scheduled stream'}
                  </div>
                  <div className="font-display text-base font-semibold text-slate-900 dark:text-white line-clamp-2">
                    {item.title}
                  </div>
                </div>
              </a>
            ))}
          </div>
        </section>
      )}

      {/* Recent Livestreams */}
      {liveData && liveData.recentLivestreams.length > 0 && (
        <section className="space-y-5">
          <h2 className="font-display text-2xl font-bold text-slate-950 dark:text-white">Recent Livestreams</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {liveData.recentLivestreams.map((video) => (
              <VideoCard key={video.id} video={video} onPlay={setActiveVideo} />
            ))}
          </div>
        </section>
      )}

      {/* Latest Uploads Fallback */}
      {liveData && !liveData.isLive && liveData.latestUploads.length > 0 && (
        <section className="space-y-5">
          <h2 className="font-display text-2xl font-bold text-slate-950 dark:text-white">Latest Uploaded Videos</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {liveData.latestUploads.slice(0, 3).map((video) => (
              <VideoCard key={`live-fb-${video.id}`} video={video} onPlay={setActiveVideo} />
            ))}
          </div>
        </section>
      )}

      <VideoPlayerModal video={activeVideo} onClose={() => setActiveVideo(null)} />
    </div>
  );
}
