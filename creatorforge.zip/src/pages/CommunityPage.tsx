import { ExternalLink, MessageSquare, Users } from 'lucide-react';
import { useSite } from '../context/SiteContext';

const COMMUNITY_LOUNGE = '/src/assets/images/community_discord_lounge_1794531452743.jpg';

export function CommunityPage() {
  const { data, navigate } = useSite();
  if (!data) return null;

  const { site, latestVideos } = data;
  const socialEntries = Object.entries(site.socialLinks || {}).filter(([, val]) => Boolean(val));

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12 sm:py-16 space-y-14">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] overflow-hidden">
        <div className="lg:col-span-7 p-8 sm:p-10 flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <div className="text-xs font-medium text-slate-500 dark:text-slate-400">
              {site.channelName} · Official Community
            </div>
            <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-950 dark:text-white headline-balance">
              Connect on Discord
            </h1>
            <p className="text-base text-slate-600 dark:text-slate-300 leading-relaxed">{site.communityPitch}</p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <a
              href={site.discordInviteUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-lg text-sm font-semibold text-slate-950 whitespace-nowrap shrink-0"
              style={{ backgroundColor: 'var(--brand-primary)' }}
            >
              <span>Join Discord Server</span>
              <ExternalLink className="w-4 h-4" />
            </a>
            <a
              href={site.youtubeChannelUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-5 py-3 rounded-lg text-sm font-semibold border border-slate-300 dark:border-white/15 text-slate-900 dark:text-white whitespace-nowrap shrink-0"
            >
              <span>YouTube Channel</span>
            </a>
          </div>
        </div>

        <div className="lg:col-span-5 min-h-[260px] bg-slate-900">
          <img
            src={COMMUNITY_LOUNGE}
            alt="Community workspace and lounge"
            className="w-full h-full lg:h-full object-cover"
          />
        </div>
      </div>

      {/* Community Highlights */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] p-6 space-y-2">
          <MessageSquare className="w-5 h-5 text-[var(--brand-primary)]" />
          <h2 className="font-display text-lg font-bold text-slate-950 dark:text-white">Upload &amp; Stream Alerts</h2>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Receive notifications in Discord when {site.channelName} goes live or publishes new videos and Shorts.
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] p-6 space-y-2">
          <Users className="w-5 h-5 text-[var(--brand-primary)]" />
          <h2 className="font-display text-lg font-bold text-slate-950 dark:text-white">Subscriber Discussions</h2>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Share feedback on recent {site.niche.toLowerCase()} episodes, suggest future topics, and meet fellow fans.
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] p-6 space-y-3">
          <h2 className="font-display text-lg font-bold text-slate-950 dark:text-white">Collaborations</h2>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Looking to sponsor a video or collaborate? Send a verified inquiry directly through our contact portal.
          </p>
          <button
            type="button"
            onClick={() => navigate('/contact')}
            className="text-sm font-semibold hover:underline"
            style={{ color: 'var(--brand-primary)' }}
          >
            Open contact form →
          </button>
        </div>
      </section>

      {/* Recent Discussion Topics from Latest Uploads */}
      {latestVideos.length > 0 && (
        <section className="rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] p-6 sm:p-8 space-y-4">
          <h2 className="font-display text-xl font-bold text-slate-950 dark:text-white">
            Recent Uploads to Discuss on Discord
          </h2>
          <div className="divide-y divide-slate-200 dark:divide-white/10">
            {latestVideos.slice(0, 4).map((v) => (
              <div key={v.id} className="py-3 flex items-center justify-between gap-4">
                <span className="text-sm font-medium text-slate-800 dark:text-slate-200 truncate">{v.title}</span>
                <a
                  href={`https://www.youtube.com/watch?v=${v.id}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs font-semibold text-slate-500 hover:text-slate-900 dark:hover:text-white whitespace-nowrap shrink-0"
                >
                  Watch →
                </a>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Social Links Directory */}
      {socialEntries.length > 0 && (
        <section className="space-y-4">
          <h2 className="font-display text-xl font-bold text-slate-950 dark:text-white">Official Social Links</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {socialEntries.map(([platform, url]) => (
              <a
                key={platform}
                href={url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-between p-4 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#11151e] hover:border-slate-300 dark:hover:border-white/25"
              >
                <span className="capitalize font-medium text-sm text-slate-900 dark:text-white">{platform}</span>
                <ExternalLink className="w-4 h-4 text-slate-400" />
              </a>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
