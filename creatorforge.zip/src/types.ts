export interface SiteConfig {
  channelName: string;
  youtubeChannelUrl: string;
  discordInviteUrl: string;
  desiredPort: number;
  channelId: string | null;
  channelHandle: string | null;
  avatarUrl: string | null;
  bannerUrl: string | null;
  channelDescription: string;
  niche: string;
  categories: string[];
  heroHeadline: string;
  heroSubheadline: string;
  aboutText: string;
  communityPitch: string;
  themeMode: 'dark' | 'light';
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  fontDisplay: string;
  fontBody: string;
  socialLinks: Record<string, string>;
  featuredVideoId: string | null;
  updatedAt: string;
}

export interface UpcomingLiveItem {
  id: string;
  title: string;
  thumbnail: string;
  scheduledStartTime: string | null;
}

export interface ChannelStats {
  subscriberCount: number | null;
  subscriberDisplay: string | null;
  hiddenSubscriberCount: boolean;
  subscriberSource: string;
  subscriberUnavailableReason: string | null;
  viewCount: number | null;
  videoCount: number | null;
  isLive: boolean;
  liveVideoId: string | null;
  liveTitle: string | null;
  liveThumbnail: string | null;
  liveStartedAt: string | null;
  liveViewers: number | null;
  upcomingLive: UpcomingLiveItem[];
  lastSubscriberSync: string | null;
  lastVideoSync: string | null;
  lastLiveSync: string | null;
  lastError: string | null;
}

export interface VideoItem {
  id: string;
  title: string;
  description: string;
  thumbnailUrl: string;
  publishedAt: string;
  durationSeconds: number | null;
  durationFormatted: string | null;
  viewCount: number | null;
  likeCount: number | null;
  category: string;
  isShort: boolean;
  isLivestream: boolean;
  liveStatus: string;
  isFeatured: boolean;
}

export interface SitePayload {
  site: SiteConfig;
  stats: ChannelStats;
  featuredVideo: VideoItem | null;
  latestVideos: VideoItem[];
  popularVideos: VideoItem[];
  latestShorts: VideoItem[];
  recentLivestreams: VideoItem[];
  configStatus: {
    youtubeApiConfigured: boolean;
    geminiApiConfigured: boolean;
  };
}

export function formatCompactNumber(num: number | null | undefined): string | null {
  if (num === null || num === undefined || Number.isNaN(num)) return null;
  if (num >= 1_000_000_000) return `${(num / 1_000_000_000).toFixed(2).replace(/\.00$/, '')}B`;
  if (num >= 1_000_000) return `${(num / 1_000_000).toFixed(2).replace(/\.00$/, '')}M`;
  if (num >= 10_000) return `${(num / 1_000).toFixed(1).replace(/\.0$/, '')}K`;
  return num.toLocaleString('en-US');
}

export function formatRelativeDate(iso: string | null | undefined): string {
  if (!iso) return 'Unknown date';
  const time = new Date(iso).getTime();
  if (Number.isNaN(time)) return 'Unknown date';
  const diffSec = Math.max(0, Math.floor((Date.now() - time) / 1000));
  if (diffSec < 60) return 'Just now';
  if (diffSec < 3600) return `${Math.floor(diffSec / 60)}m ago`;
  if (diffSec < 86400) return `${Math.floor(diffSec / 3600)}h ago`;
  if (diffSec < 604800) return `${Math.floor(diffSec / 86400)}d ago`;
  return new Date(time).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}
