import { ErrorBoundary } from './components/ErrorBoundary';
import { Footer } from './components/Footer';
import { Navbar } from './components/Navbar';
import { SiteProvider, useSite } from './context/SiteContext';
import { AboutPage } from './pages/AboutPage';
import { AdminPage } from './pages/AdminPage';
import { CommunityPage } from './pages/CommunityPage';
import { ContactPage } from './pages/ContactPage';
import { GeneratorPage } from './pages/GeneratorPage';
import { HomePage } from './pages/HomePage';
import { LivePage } from './pages/LivePage';
import { ShortsPage } from './pages/ShortsPage';
import { VideosPage } from './pages/VideosPage';

function PageRouter() {
  const { currentPath } = useSite();
  const normalized = currentPath.replace(/\/+$/, '') || '/';

  switch (normalized) {
    case '/':
      return <HomePage />;
    case '/about':
      return <AboutPage />;
    case '/videos':
      return <VideosPage />;
    case '/shorts':
      return <ShortsPage />;
    case '/live':
      return <LivePage />;
    case '/community':
      return <CommunityPage />;
    case '/contact':
      return <ContactPage />;
    case '/setup':
      return <GeneratorPage />;
    case '/admin':
      return <AdminPage />;
    default:
      return <HomePage />;
  }
}

export default function App() {
  return (
    <ErrorBoundary>
      <SiteProvider>
        <div className="min-h-screen flex flex-col bg-[var(--bg-canvas)] text-[var(--text-primary)] transition-colors duration-200">
          <Navbar />
          <main className="flex-1">
            <PageRouter />
          </main>
          <Footer />
        </div>
      </SiteProvider>
    </ErrorBoundary>
  );
}
